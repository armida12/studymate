// ======================================
// StudyMate AI - Quiz JavaScript
// ======================================

// Force redirect to login if not logged in
if (localStorage.getItem("isLoggedIn") !== "true") {
    window.location.href = "login.html";
}

let currentQuestion = 0;
let score = 0;
let timer;
let timeLeft = 30;
let quizQuestions = [];
let quizTopic = "General Knowledge";

// ======================================
// Start Quiz
// ======================================

async function startQuiz() {

    const topicInput =
        document.getElementById("quizTopic");

    quizTopic = topicInput
        ? topicInput.value.trim()
        : "General Knowledge";

    if (quizTopic === "") {
        quizTopic = "General Knowledge";
    }

    currentQuestion = 0;
    score = 0;

    try {

        const response = await fetch(
            "http://127.0.0.1:5000/generate_quiz",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    topic: quizTopic,
                    difficulty: "medium",
                    number_of_questions: 5
                })
            }
        );

        const data = await response.json();

        if (!data.success) {
            alert(data.message);
            return;
        }

        quizQuestions = data.questions;

        document.getElementById(
            "resultContainer"
        ).style.display = "none";

        document.getElementById(
            "quizContainer"
        ).style.display = "block";

        loadQuestion();

    }
    catch (error) {

        console.error(error);

        alert(
            "Unable to connect to backend server."
        );

    }

}

// ======================================
// Load Question
// ======================================

function loadQuestion() {

    clearInterval(timer);

    timeLeft = 30;

    startTimer();

    const questionData =
        quizQuestions[currentQuestion];

    document.getElementById(
        "questionNumber"
    ).textContent =
        `Question ${currentQuestion + 1} of ${quizQuestions.length}`;

    document.getElementById(
        "questionText"
    ).textContent =
        questionData.question;

    const optionsContainer =
        document.getElementById(
            "optionsContainer"
        );

    optionsContainer.innerHTML = "";

    questionData.options.forEach(
        (option, index) => {

            const button =
                document.createElement("button");

            button.classList.add(
                "option-btn"
            );

            button.textContent = option;

            button.onclick =
                () => selectAnswer(index);

            optionsContainer.appendChild(
                button
            );

        }
    );

    updateProgressBar();

}

// ======================================
// Select Answer
// ======================================

function selectAnswer(selectedIndex) {

    const correctAnswer =
        quizQuestions[currentQuestion]
            .answer;

    const buttons =
        document.querySelectorAll(
            ".option-btn"
        );

    buttons.forEach(
        button => button.disabled = true
    );

    const correctIndex =
        quizQuestions[currentQuestion]
            .options.indexOf(
                correctAnswer
            );

    if (
        selectedIndex === correctIndex
    ) {

        score++;

        buttons[selectedIndex]
            .classList.add(
                "correct"
            );

    }
    else {

        buttons[selectedIndex]
            .classList.add(
                "wrong"
            );

        buttons[correctIndex]
            .classList.add(
                "correct"
            );

    }

    setTimeout(
        nextQuestion,
        1500
    );

}

// ======================================
// Next Question
// ======================================

function nextQuestion() {

    currentQuestion++;

    if (
        currentQuestion <
        quizQuestions.length
    ) {

        loadQuestion();

    }
    else {

        finishQuiz();

    }

}

// ======================================
// Finish Quiz
// ======================================

async function finishQuiz() {

    clearInterval(timer);

    document.getElementById(
        "quizContainer"
    ).style.display = "none";

    document.getElementById(
        "resultContainer"
    ).style.display = "block";

    const percentage =
        Math.round(
            (
                score /
                quizQuestions.length
            ) * 100
        );

    document.getElementById(
        "scoreText"
    ).textContent =
        `You scored ${score} out of ${quizQuestions.length}`;

    document.getElementById(
        "percentageText"
    ).textContent =
        `${percentage}%`;

    localStorage.setItem(
        "lastQuizScore",
        percentage
    );

    // Save result to backend

    try {

        const currentUser =
            JSON.parse(
                localStorage.getItem(
                    "currentUser"
                )
            );

        if (currentUser) {

            await fetch(
                "http://127.0.0.1:5000/submit_quiz",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        user_id:
                            currentUser.id,
                        topic:
                            quizTopic,
                        score:
                            score,
                        total_questions:
                            quizQuestions.length
                    })
                }
            );

        }

    }
    catch (error) {

        console.error(
            "Failed to save quiz result",
            error
        );

    }

}

// ======================================
// Timer
// ======================================

function startTimer() {

    document.getElementById(
        "timer"
    ).textContent =
        `${timeLeft}s`;

    timer =
        setInterval(() => {

            timeLeft--;

            document.getElementById(
                "timer"
            ).textContent =
                `${timeLeft}s`;

            if (timeLeft <= 0) {

                clearInterval(timer);

                nextQuestion();

            }

        }, 1000);

}

// ======================================
// Progress Bar
// ======================================

function updateProgressBar() {

    const progress =
        (
            (
                currentQuestion + 1
            ) /
            quizQuestions.length
        ) * 100;

    document.getElementById(
        "progressBar"
    ).style.width =
        `${progress}%`;

}

// ======================================
// Restart Quiz
// ======================================

function restartQuiz() {

    startQuiz();

}