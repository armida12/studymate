// =============================
// StudyMate AI - Main JavaScript
// =============================

// Wait until page loads
document.addEventListener("DOMContentLoaded", () => {

    console.log("StudyMate AI Loaded Successfully");

    initializeGreeting();
    initializeSidebar();
    initializeTheme();
    initializeTooltips();

});

// =============================
// Dynamic Greeting
// =============================

function initializeGreeting() {

    const greetingElement = document.getElementById("greeting");

    if (!greetingElement) return;

    const hour = new Date().getHours();

    let greeting = "Welcome";

    if (hour < 12) {
        greeting = "Good Morning ☀️";
    } else if (hour < 18) {
        greeting = "Good Afternoon 🌤️";
    } else {
        greeting = "Good Evening 🌙";
    }

    greetingElement.textContent = greeting;
}

// =============================
// Sidebar Active Menu
// =============================

function initializeSidebar() {

    const menuLinks = document.querySelectorAll(".menu a");

    menuLinks.forEach(link => {

        link.addEventListener("click", function () {

            menuLinks.forEach(item =>
                item.parentElement.classList.remove("active")
            );

            this.parentElement.classList.add("active");

        });

    });

}

// =============================
// Theme Management
// =============================

function initializeTheme() {

    const themeButton = document.getElementById("theme-toggle");

    if (!themeButton) return;

    const savedTheme = localStorage.getItem("theme");

    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
    }

    themeButton.addEventListener("click", () => {

        document.body.classList.toggle("dark-mode");

        if (document.body.classList.contains("dark-mode")) {
            localStorage.setItem("theme", "dark");
        } else {
            localStorage.setItem("theme", "light");
        }

    });
}

// =============================
// Notification Utility
// =============================

function showNotification(message, type = "success") {

    const notification = document.createElement("div");

    notification.className = `notification ${type}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add("show");
    }, 100);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Example:
// showNotification("Login Successful");
// showNotification("Invalid Password", "error");

// =============================
// Loading Screen
// =============================

function showLoader() {

    const loader = document.getElementById("loader");

    if (loader) {
        loader.style.display = "flex";
    }
}

function hideLoader() {

    const loader = document.getElementById("loader");

    if (loader) {
        loader.style.display = "none";
    }
}

// =============================
// Smooth Scroll
// =============================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {

    anchor.addEventListener("click", function (e) {

        e.preventDefault();

        const target = document.querySelector(this.getAttribute("href"));

        if (target) {
            target.scrollIntoView({
                behavior: "smooth"
            });
        }

    });

});

// =============================
// Local Storage Helpers
// =============================

function saveData(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

function getData(key) {
    return JSON.parse(localStorage.getItem(key));
}

function removeData(key) {
    localStorage.removeItem(key);
}

// =============================
// Tooltip Initialization
// =============================

function initializeTooltips() {

    const tooltips = document.querySelectorAll("[data-tooltip]");

    tooltips.forEach(element => {

        element.addEventListener("mouseenter", () => {
            console.log(element.dataset.tooltip);
        });

    });
}

// =============================
// Logout Function
// =============================

function logout() {

    localStorage.clear();

    alert("Logged out successfully.");

    window.location.href = "login.html";
}