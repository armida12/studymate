// ======================================
// StudyMate AI - Profile JavaScript
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
    // Force redirect to login if not logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    loadProfile();

    const profileForm = document.getElementById("profileForm");
    if (profileForm) {
        profileForm.addEventListener("submit", saveProfile);
    }
});

// ======================================
// Load Profile
// ======================================

async function loadProfile() {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (!currentUser || !currentUser.id) return;

    // Display basic currentUser defaults first
    document.getElementById("fullName").value = currentUser.name || "";
    document.getElementById("email").value = currentUser.email || "";
    document.getElementById("dispName").textContent = currentUser.name || "Student";
    document.getElementById("dispEmail").textContent = currentUser.email || "";

    try {
        const response = await fetch(`${API_BASE_URL}/profile/${currentUser.id}`);
        const data = await response.json();

        if (data.success && data.profile) {
            const prof = data.profile;
            
            // Populate inputs
            document.getElementById("fullName").value = prof.name || "";
            document.getElementById("phone").value = prof.phone || "";
            document.getElementById("bioInput").value = prof.bio || "";
            
            // Update display
            document.getElementById("dispName").textContent = prof.name || "Student";
            document.getElementById("dispBio").textContent = prof.bio || "No bio added yet.";
            document.getElementById("dispPhone").textContent = prof.phone ? `Phone: ${prof.phone}` : "Phone: N/A";
            
            if (prof.profile_picture) {
                document.getElementById("profileImage").src = prof.profile_picture;
            }
        }
    } catch (error) {
        console.error("Failed to load profile from server:", error);
        // Fall back to local storage
        const savedProfile = JSON.parse(localStorage.getItem("studentProfile"));
        if (savedProfile) {
            document.getElementById("fullName").value = savedProfile.fullName || "";
            document.getElementById("college").value = savedProfile.college || "";
            document.getElementById("course").value = savedProfile.course || "";
            document.getElementById("year").value = savedProfile.year || "";
            document.getElementById("interests").value = savedProfile.interests || "";
            document.getElementById("goal").value = savedProfile.goal || "";
        }
        
        const savedImage = localStorage.getItem("profilePicture");
        if (savedImage) {
            document.getElementById("profileImage").src = savedImage;
        }
    }

    // Load academic metadata from local storage (non-database profile extensions)
    const savedProfile = JSON.parse(localStorage.getItem("studentProfile"));
    if (savedProfile) {
        document.getElementById("college").value = savedProfile.college || "";
        document.getElementById("course").value = savedProfile.course || "";
        document.getElementById("year").value = savedProfile.year || "";
        document.getElementById("interests").value = savedProfile.interests || "";
        document.getElementById("goal").value = savedProfile.goal || "";
    }
}

// ======================================
// Save Profile
// ======================================

async function saveProfile(event) {
    event.preventDefault();

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (!currentUser || !currentUser.id) return;

    const name = document.getElementById("fullName").value;
    const phone = document.getElementById("phone").value;
    const bio = document.getElementById("bioInput").value;

    // Academic fields saved in local storage (extended schema)
    const academicProfile = {
        fullName: name,
        email: document.getElementById("email").value,
        college: document.getElementById("college").value,
        course: document.getElementById("course").value,
        year: document.getElementById("year").value,
        interests: document.getElementById("interests").value,
        goal: document.getElementById("goal").value
    };

    try {
        // Save core fields to database
        const response = await fetch(`${API_BASE_URL}/update_profile`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: currentUser.id,
                name: name,
                phone: phone,
                bio: bio
            })
        });

        const data = await response.json();

        if (data.success) {
            // Save extended fields to localStorage
            localStorage.setItem("studentProfile", JSON.stringify(academicProfile));
            
            // Update UI displays
            document.getElementById("dispName").textContent = name;
            document.getElementById("dispBio").textContent = bio || "No bio added yet.";
            document.getElementById("dispPhone").textContent = phone ? `Phone: ${phone}` : "Phone: N/A";
            
            // Update cached currentUser name
            currentUser.name = name;
            localStorage.setItem("currentUser", JSON.stringify(currentUser));

            alert("Profile updated successfully!");
        } else {
            alert("Error: " + data.message);
        }
    } catch (error) {
        console.error("Profile update error:", error);
        alert("Failed to update profile on the server. Saving locally instead.");
        localStorage.setItem("studentProfile", JSON.stringify(academicProfile));
    }
}

// ======================================
// Profile Picture Upload
// ======================================

async function previewImage(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async function(e) {
        const base64Image = e.target.result;
        document.getElementById("profileImage").src = base64Image;

        const currentUser = JSON.parse(localStorage.getItem("currentUser"));
        if (currentUser && currentUser.id) {
            try {
                const response = await fetch(`${API_BASE_URL}/update_profile_picture`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        user_id: currentUser.id,
                        profile_picture: base64Image
                    })
                });
                const data = await response.json();
                if (data.success) {
                    localStorage.setItem("profilePicture", base64Image);
                    alert("Profile picture updated!");
                }
            } catch (error) {
                console.error("Photo upload error:", error);
                localStorage.setItem("profilePicture", base64Image);
            }
        } else {
            localStorage.setItem("profilePicture", base64Image);
        }
    };
    reader.readAsDataURL(file);
}

// ======================================
// Clear Profile
// ======================================

function clearProfile() {
    if (confirm("Are you sure you want to delete profile information?")) {
        localStorage.removeItem("studentProfile");
        localStorage.removeItem("profilePicture");
        location.reload();
    }
}