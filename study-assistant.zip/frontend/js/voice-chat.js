// ======================================
// StudyMate AI - Voice Chat JavaScript
// ======================================

// Browser compatibility
const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

let recognition;

// ======================================
// Initialize Speech Recognition
// ======================================

if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    // Voice detected successfully
    recognition.onresult = function(event) {

        const transcript =
            event.results[0][0].transcript;

        const inputField =
            document.getElementById("userInput");

        if (inputField) {
            inputField.value = transcript;
        }

        console.log("Recognized:", transcript);
    };

    // Handle errors
    recognition.onerror = function(event) {
        alert(
            "Voice recognition error: " +
            event.error
        );
    };

    recognition.onend = function() {

        const micButton =
            document.getElementById("voiceBtn");

        if (micButton) {
            micButton.classList.remove("recording");
        }
    };

}

// ======================================
// Start Voice Recording
// ======================================

function startVoiceRecording() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported in your browser."
        );

        return;
    }

    const micButton =
        document.getElementById("voiceBtn");

    if (micButton) {
        micButton.classList.add("recording");
    }

    recognition.start();

    console.log("Recording started...");
}

// ======================================
// Stop Voice Recording
// ======================================

function stopVoiceRecording() {

    if (recognition) {
        recognition.stop();
    }

    const micButton =
        document.getElementById("voiceBtn");

    if (micButton) {
        micButton.classList.remove("recording");
    }

    console.log("Recording stopped.");
}

// ======================================
// AI Text To Speech
// ======================================

function speakResponse(text) {

    if (!window.speechSynthesis) {
        return;
    }

    const speech =
        new SpeechSynthesisUtterance(text);

    speech.lang = "en-US";
    speech.rate = 1;
    speech.pitch = 1;
    speech.volume = 1;

    window.speechSynthesis.speak(speech);
}

// ======================================
// Stop AI Speech
// ======================================

function stopSpeaking() {
    window.speechSynthesis.cancel();
}

// ======================================
// Change Voice Language
// ======================================

function changeVoiceLanguage(language) {

    if (recognition) {
        recognition.lang = language;
    }
}