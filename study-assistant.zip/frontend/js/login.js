// =====================================
// StudyMate AI - Login JavaScript
// =====================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const togglePassword = document.getElementById("togglePassword");

    // =====================================
    // Show / Hide Password
    // =====================================

    if (togglePassword && passwordInput) {

        togglePassword.addEventListener("click", () => {

            const type =
                passwordInput.type === "password"
                    ? "text"
                    : "password";

            passwordInput.type = type;

            togglePassword.classList.toggle("fa-eye");
            togglePassword.classList.toggle("fa-eye-slash");

        });

    }

    // =====================================
    // Login Form Submission
    // =====================================

    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();

                const email =
                    emailInput.value.trim();

                const password =
                    passwordInput.value.trim();

                // -------------------------
                // Validation
                // -------------------------

                if (!email || !password) {

                    alert(
                        "Please fill in all fields."
                    );

                    return;
                }

                if (!validateEmail(email)) {

                    alert(
                        "Please enter a valid email address."
                    );

                    return;
                }

                try {

                    const response =
                        await fetch(
                            `${API_BASE_URL}/login`,
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body: JSON.stringify({
                                    email: email,
                                    password: password
                                })
                            }
                        );

                    if (!response.ok) {

                        throw new Error(
                            `Server error: ${response.status}`
                        );

                    }

                    const data =
                        await response.json();

                    // -------------------------
                    // Login Successful
                    // -------------------------

                    if (data.success) {

                        localStorage.setItem(
                            "isLoggedIn",
                            "true"
                        );

                        localStorage.setItem(
                            "currentUser",
                            JSON.stringify(
                                data.user
                            )
                        );

                        alert(
                            `Welcome back, ${data.user.name}!`
                        );

                        window.location.href =
                            "dashboard.html";

                    }

                    // -------------------------
                    // Login Failed
                    // -------------------------

                    else {

                        alert(
                            data.message ||
                            "Invalid email or password."
                        );

                    }

                }

                catch (error) {

                    console.error(
                        "Login Error:",
                        error
                    );

                    alert(
                        "Unable to connect to the server. Please ensure Flask is running."
                    );

                }

            }
        );

    }

});

// =====================================
// Email Validation
// =====================================

function validateEmail(email) {

    const regex =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return regex.test(email);

}

// =====================================
// Logout Function
// =====================================

function logout() {

    localStorage.removeItem(
        "isLoggedIn"
    );

    localStorage.removeItem(
        "currentUser"
    );

    window.location.href =
        "login.html";

}