// ======================================
// StudyMate AI - Notifications
// ======================================

document.addEventListener("DOMContentLoaded", () => {

    initializeNotifications();
    checkDailyReminder();

});

// ======================================
// Initialize Notifications
// ======================================

function initializeNotifications() {

    const settings =
        JSON.parse(
            localStorage.getItem("studyMateSettings")
        );

    if (
        settings &&
        settings.notifications === false
    ) {
        return;
    }

    if ("Notification" in window) {

        if (Notification.permission !== "granted") {
            Notification.requestPermission();
        }
    }
}

// ======================================
// Show Notification
// ======================================

function showNotification(
    title,
    message,
    duration = 4000
) {

    // Browser Notification
    if (
        "Notification" in window &&
        Notification.permission === "granted"
    ) {

        new Notification(title, {
            body: message,
            icon: "assets/images/logo.png"
        });
    }

    // In-App Notification
    const notification =
        document.createElement("div");

    notification.className =
        "study-notification";

    notification.innerHTML = `
        <div class="notification-content">
            <h4>${title}</h4>
            <p>${message}</p>
        </div>
        <button class="close-btn">&times;</button>
    `;

    document.body.appendChild(notification);

    // Close Button
    notification
        .querySelector(".close-btn")
        .addEventListener("click", () => {
            notification.remove();
        });

    // Auto Remove
    setTimeout(() => {

        if (
            document.body.contains(
                notification
            )
        ) {
            notification.remove();
        }

    }, duration);
}

// ======================================
// Study Reminder
// ======================================

function sendStudyReminder() {

    showNotification(
        "Study Reminder 📚",
        "Time for your daily study session!"
    );
}

// ======================================
// Quiz Reminder
// ======================================

function sendQuizReminder() {

    showNotification(
        "Quiz Reminder 📝",
        "Try taking a quiz to test your knowledge."
    );
}

// ======================================
// Goal Reminder
// ======================================

function sendGoalReminder() {

    showNotification(
        "Daily Goal 🎯",
        "Complete today's study target."
    );
}

// ======================================
// Daily Reminder Check
// ======================================

function checkDailyReminder() {

    const lastReminder =
        localStorage.getItem(
            "lastReminderDate"
        );

    const today =
        new Date().toDateString();

    if (lastReminder !== today) {

        sendStudyReminder();

        localStorage.setItem(
            "lastReminderDate",
            today
        );
    }
}

// ======================================
// Custom Notification Examples
// ======================================

// showNotification(
//     "Welcome",
//     "Welcome back to StudyMate AI!"
// );

// showNotification(
//     "Quiz Completed",
//     "You scored 90% on your latest quiz."
// );