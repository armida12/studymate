﻿// ======================================
// StudyMate AI - PDF Summarizer
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";
let selectedFile = null;

document.addEventListener("DOMContentLoaded", () => {

    // Login guard — consistent with all other pages
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    const dropZone = document.getElementById("dropZone");
    if (!dropZone) return;

    // Drag-and-Drop highlight
    ["dragenter", "dragover"].forEach(evt => {
        dropZone.addEventListener(evt, (e) => {
            e.preventDefault();
            dropZone.classList.add("dragover");
        }, false);
    });

    ["dragleave", "drop"].forEach(evt => {
        dropZone.addEventListener(evt, (e) => {
            e.preventDefault();
            dropZone.classList.remove("dragover");
        }, false);
    });

    // Handle dropped file
    dropZone.addEventListener("drop", (e) => {
        const files = e.dataTransfer && e.dataTransfer.files;
        if (files && files.length > 0) handleFile(files[0]);
    });
});

// ======================================
// File Selection Handler
// ======================================

function handleFileSelect(event) {
    const files = event.target.files;
    if (files && files.length > 0) handleFile(files[0]);
}

function handleFile(file) {
    if (!file || file.type !== "application/pdf") {
        showError("Only PDF files are supported. Please select a .pdf file.");
        return;
    }

    selectedFile = file;

    const fileNameEl = document.getElementById("fileName");
    const fileInfoEl = document.getElementById("fileInfo");

    if (fileNameEl) fileNameEl.textContent = file.name + " (" + formatFileSize(file.size) + ")";
    if (fileInfoEl) fileInfoEl.style.display = "flex";

    // Hide old summary when new file is picked
    const summaryCard = document.getElementById("summaryCard");
    if (summaryCard) summaryCard.style.display = "none";
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

// ======================================
// Clear Selection
// ======================================

function clearSelection() {
    selectedFile = null;

    const fileInputEl = document.getElementById("fileInput");
    const fileNameEl = document.getElementById("fileName");
    const fileInfoEl = document.getElementById("fileInfo");
    const summaryCard = document.getElementById("summaryCard");
    const summaryContent = document.getElementById("summaryContent");

    if (fileInputEl) fileInputEl.value = "";
    if (fileNameEl) fileNameEl.textContent = "No file chosen";
    if (fileInfoEl) fileInfoEl.style.display = "none";
    if (summaryCard) summaryCard.style.display = "none";
    if (summaryContent) summaryContent.innerHTML = "";
}

// ======================================
// Upload and Summarize
// ======================================

async function uploadAndSummarize() {
    if (!selectedFile) {
        showError("Please select or drop a PDF file first.");
        return;
    }

    const loader = document.getElementById("loader");
    const summaryCard = document.getElementById("summaryCard");
    const summarizeBtn = document.getElementById("summarizeBtn");
    const summaryContent = document.getElementById("summaryContent");

    if (loader) loader.style.display = "flex";
    if (summaryCard) summaryCard.style.display = "none";
    if (summarizeBtn) summarizeBtn.disabled = true;

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
        const response = await fetch(`${API_BASE_URL}/summarize_pdf`, {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (loader) loader.style.display = "none";
        if (summarizeBtn) summarizeBtn.disabled = false;

        if (data.success) {
            const summaryHtml = convertMarkdownToHtml(data.summary);
            if (summaryContent) summaryContent.innerHTML = summaryHtml;
            if (summaryCard) summaryCard.style.display = "block";

            // Scroll smoothly to the summary
            summaryCard && summaryCard.scrollIntoView({ behavior: "smooth", block: "start" });
        } else {
            showError(data.message || "Failed to generate summary. Please try again.");
        }

    } catch (error) {
        console.error("Summarizer error:", error);
        if (loader) loader.style.display = "none";
        if (summarizeBtn) summarizeBtn.disabled = false;
        showError("Unable to connect to the backend server. Make sure the Flask server is running on port 5000.");
    }
}

// ======================================
// Show Error Message
// ======================================

function showError(message) {
    const summaryContent = document.getElementById("summaryContent");
    const summaryCard = document.getElementById("summaryCard");
    if (summaryContent) {
        summaryContent.innerHTML = `<div style="color:#e74c3c; padding: 15px; border: 1px solid #e74c3c; border-radius: 8px; background: #fff5f5;">
            <strong><i class="fa-solid fa-circle-exclamation"></i> Error:</strong> ${message}
        </div>`;
    }
    if (summaryCard) summaryCard.style.display = "block";
}

// ======================================
// Markdown → HTML Converter
// ======================================

function convertMarkdownToHtml(md) {
    let html = md;

    // Headings
    html = html.replace(/^### (.*$)/gim, "<h3>$1</h3>");
    html = html.replace(/^## (.*$)/gim, "<h2>$1</h2>");
    html = html.replace(/^# (.*$)/gim, "<h1>$1</h1>");

    // Bold
    html = html.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

    // Italic
    html = html.replace(/\*(.*?)\*/g, "<em>$1</em>");

    // Numbered lists
    html = html.replace(/^\d+\. (.*$)/gim, "<li>$1</li>");

    // Bullet lists
    html = html.replace(/^[-•] (.*$)/gim, "<li>$1</li>");

    // Wrap adjacent <li> in <ul>
    html = html.replace(/(<li>.*<\/li>)/gs, "<ul>$1</ul>");
    html = html.replace(/<\/ul>\s*<ul>/g, "");

    // Line breaks to paragraphs
    html = html.split("\n\n").map(p => {
        const trimmed = p.trim();
        if (!trimmed) return "";
        if (trimmed.startsWith("<h") || trimmed.startsWith("<ul") || trimmed.startsWith("<li")) return trimmed;
        return `<p>${trimmed}</p>`;
    }).join("\n");

    return html;
}

// ======================================
// Copy / Print
// ======================================

function copySummary() {
    const text = document.getElementById("summaryContent")?.innerText || "";
    navigator.clipboard.writeText(text).then(() => {
        alert("Summary copied to clipboard!");
    }).catch(err => {
        console.error("Copy failed:", err);
    });
}

function printSummary() {
    window.print();
}
