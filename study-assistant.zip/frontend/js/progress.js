﻿// ======================================
// StudyMate AI - Progress Dashboard
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";

let progressData = {
    studyHours:       0,
    completedTopics:  0,
    quizzesCompleted: 0,
    averageScore:     0,
    streak:           1
};

document.addEventListener("DOMContentLoaded", () => {

    // Login guard
    if (localStorage.getItem("isLoggedIn") !== "true") {
        window.location.href = "login.html";
        return;
    }

    // Load from local storage first for instant display
    const saved = JSON.parse(localStorage.getItem("studyProgress") || "null");
    if (saved) Object.assign(progressData, saved);

    updateDashboard();
    checkAchievements();
    generateRecommendation();

    // Then try to get real data from backend
    loadProgressFromBackend();
});

// ======================================
// Load from Backend
// ======================================

async function loadProgressFromBackend() {
    const user = JSON.parse(localStorage.getItem("currentUser") || "{}");
    if (!user.id) return;

    try {
        const res  = await fetch(`${API_BASE_URL}/progress/${user.id}`);
        const data = await res.json();
        if (data.success) {
            const p = data.progress || {};
            progressData.quizzesCompleted = p.total_quizzes    || progressData.quizzesCompleted;
            progressData.averageScore     = p.average_score    || progressData.averageScore;
            progressData.completedTopics  = p.topics_completed || progressData.completedTopics;
            saveProgress();
            updateDashboard();
            checkAchievements();
            generateRecommendation();
        }
    } catch (_) { /* use local fallback */ }
}

// ======================================
// Add Study Hours
// ======================================

function addStudyHours() {
    const input = document.getElementById("studyHoursInput");
    const hours = parseInt(input ? input.value : "0");
    if (isNaN(hours) || hours <= 0) { alert("Please enter valid hours."); return; }
    progressData.studyHours += hours;
    saveProgress();
    updateDashboard();
    if (input) input.value = "";
    showToast(`Added ${hours} study hour${hours > 1 ? "s" : ""}!`);
}

// ======================================
// Complete a Topic
// ======================================

function completeTopic() {
    progressData.completedTopics++;
    saveProgress();
    updateDashboard();
    checkAchievements();
    showToast("Topic marked as completed! 🎉");
}

// ======================================
// Add Quiz Score
// ======================================

function addQuizScore(score) {
    progressData.quizzesCompleted++;
    const total = progressData.averageScore * (progressData.quizzesCompleted - 1);
    progressData.averageScore = Math.round((total + score) / progressData.quizzesCompleted);
    saveProgress();
    updateDashboard();
}

// ======================================
// Study Streak Calculation
// ======================================

function updateStreak() {
    const today     = new Date().toDateString();
    const lastVisit = localStorage.getItem("lastVisit");
    if (lastVisit !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        if (lastVisit === yesterday.toDateString()) {
            progressData.streak++;
        } else if (lastVisit && lastVisit !== today) {
            progressData.streak = 1; // streak broken
        }
        localStorage.setItem("lastVisit", today);
    }
}

// ======================================
// Update Dashboard UI
// ======================================

function updateDashboard() {
    updateStreak();

    const set = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    };

    set("studyHours",       progressData.studyHours);
    set("completedTopics",  progressData.completedTopics);
    set("quizzesCompleted", progressData.quizzesCompleted);
    set("averageScore",     progressData.averageScore + "%");
    set("studyStreak",      progressData.streak + " Days");

    updateProgressBar();
}

// ======================================
// Progress Bar
// ======================================

function updateProgressBar() {
    const pct  = Math.min(Math.round((progressData.completedTopics / 100) * 100), 100);
    const bar  = document.getElementById("overallProgress");
    const text = document.getElementById("overallPercentage");
    if (bar)  bar.style.width    = pct + "%";
    if (text) text.textContent   = pct + "% Completed";
}

// ======================================
// Achievements
// ======================================

function checkAchievements() {
    const list = [];
    if (progressData.studyHours    >= 10)  list.push("📚 10 Study Hours Logged");
    if (progressData.studyHours    >= 50)  list.push("🏆 50 Study Hours Completed");
    if (progressData.studyHours    >= 100) list.push("🔥 Joined the 100-Hour Club");
    if (progressData.streak        >= 3)   list.push("⚡ 3-Day Streak");
    if (progressData.streak        >= 7)   list.push("⭐ 7-Day Study Streak");
    if (progressData.averageScore  >= 70)  list.push("✅ Quiz Consistent (70%+)");
    if (progressData.averageScore  >= 90)  list.push("🎯 Quiz Master (90%+)");
    if (progressData.completedTopics >= 10) list.push("📖 10 Topics Mastered");

    const el = document.getElementById("achievementList");
    if (!el) return;
    if (list.length === 0) {
        el.innerHTML = "<li style='color:#999;'>Complete more activities to unlock achievements!</li>";
        return;
    }
    el.innerHTML = list.map(a => `<li>${a}</li>`).join("");
}

// ======================================
// AI Recommendation
// ======================================

function generateRecommendation() {
    let rec = "Great work! Keep up the consistent study habit. 💪";
    if (progressData.studyHours     < 5)   rec = "Try to log at least 1 hour of study per day to build momentum.";
    else if (progressData.averageScore < 60) rec = "Your quiz scores need improvement — focus on revision and practice tests.";
    else if (progressData.streak     < 3)   rec = "Consistency is key! Aim to study every day and build your streak.";
    else if (progressData.completedTopics < 5) rec = "Try to complete at least 1 topic per study session to track progress.";

    const el = document.getElementById("aiRecommendation");
    if (el) el.textContent = rec;
}

// ======================================
// Save Progress
// ======================================

function saveProgress() {
    localStorage.setItem("studyProgress", JSON.stringify(progressData));
}

// ======================================
// Reset Progress
// ======================================

function resetProgress() {
    if (confirm("Reset all progress data? This cannot be undone.")) {
        localStorage.removeItem("studyProgress");
        location.reload();
    }
}

// ======================================
// Toast notification
// ======================================

function showToast(msg) {
    const t = document.createElement("div");
    t.textContent = msg;
    t.style.cssText = "position:fixed;bottom:25px;right:25px;background:#6f42c1;color:white;padding:12px 22px;border-radius:8px;font-family:Poppins,sans-serif;font-size:14px;box-shadow:0 4px 15px rgba(0,0,0,.2);z-index:9999;";
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}
