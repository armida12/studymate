// ======================================
// StudyMate AI - Exam Preparation
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
    // Force redirect to login if not logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    loadSavedPlan();

    const examForm = document.getElementById("examForm");
    if (examForm) {
        examForm.addEventListener("submit", generateStudyPlan);
    }

    const importantTopicsBtn = document.getElementById("importantTopicsBtn");
    if (importantTopicsBtn) {
        importantTopicsBtn.addEventListener("click", getImportantTopics);
    }

    const generateMockBtn = document.getElementById("generateMockBtn");
    if (generateMockBtn) {
        generateMockBtn.addEventListener("click", generateMockTest);
    }
});

// ======================================
// Generate Study Plan via AI
// ======================================

async function generateStudyPlan(event) {
    if (event) event.preventDefault();

    const subject = document.getElementById("subject").value;
    const examDate = document.getElementById("examDate").value;
    const studyHours = document.getElementById("studyHours").value;
    const syllabus = document.getElementById("syllabus").value;
    const resultContainer = document.getElementById("studyPlan");

    if (!subject || !examDate || !syllabus) {
        alert("Please fill in subject, date and syllabus.");
        return;
    }

    resultContainer.innerHTML = "<h2>Generating Study Plan...</h2><p>Our AI is crafting a personalized timeline for you. Please wait.</p>";
    resultContainer.style.display = "block";

    const daysRemaining = calculateDaysRemaining(examDate);

    try {
        const response = await fetch(`${API_BASE_URL}/generate_study_plan`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                syllabus: syllabus,
                days_available: daysRemaining
            })
        });

        const data = await response.json();
        if (data.success) {
            // Render markdown or text
            const formattedPlan = data.study_plan.replace(/\n/g, "<br>");
            resultContainer.innerHTML = `
                <h2>Study Plan for ${subject}</h2>
                <p><strong>Exam Date:</strong> ${examDate}</p>
                <p><strong>Days Remaining:</strong> ${daysRemaining} days (Study Goal: ${studyHours} hours/day)</p>
                <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
                <div class="plan-content" style="line-height: 1.6; text-align: left;">
                    ${formattedPlan}
                </div>
            `;
            
            // Save plan to database if user is logged in
            const currentUser = JSON.parse(localStorage.getItem("currentUser"));
            if (currentUser && currentUser.id) {
                // Save progress
                await fetch(`${API_BASE_URL}/save_exam_progress`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        user_id: currentUser.id,
                        subject: subject,
                        completion: 10 // Start with 10% progress
                    })
                });
            }

            // Save plan locally
            savePlan(subject, examDate, data.study_plan);
        } else {
            resultContainer.innerHTML = `<h2>Error</h2><p>${data.message}</p>`;
        }
    } catch (error) {
        console.error("Study Plan generation error:", error);
        resultContainer.innerHTML = "<h2>Error</h2><p>Unable to connect to backend server. Please ensure Flask is running.</p>";
    }
}

// ======================================
// Get Important Topics via AI
// ======================================

async function getImportantTopics() {
    const subject = document.getElementById("subject").value;
    const syllabus = document.getElementById("syllabus").value;
    const resultContainer = document.getElementById("studyPlan");

    if (!subject || !syllabus) {
        alert("Please fill in subject and syllabus first.");
        return;
    }

    resultContainer.innerHTML = "<h2>Analyzing Syllabus...</h2><p>AI is highlighting key concepts and repeated themes. Please wait.</p>";
    resultContainer.style.display = "block";

    try {
        const response = await fetch(`${API_BASE_URL}/important_questions`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                subject: subject,
                syllabus: syllabus
            })
        });

        const data = await response.json();
        if (data.success) {
            const formattedTopics = data.questions.replace(/\n/g, "<br>");
            resultContainer.innerHTML = `
                <h2>Important Topics for ${subject}</h2>
                <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
                <div class="plan-content" style="line-height: 1.6; text-align: left;">
                    ${formattedTopics}
                </div>
            `;
        } else {
            resultContainer.innerHTML = `<h2>Error</h2><p>${data.message}</p>`;
        }
    } catch (error) {
        console.error("Topics analysis error:", error);
        resultContainer.innerHTML = "<h2>Error</h2><p>Unable to connect to backend server.</p>";
    }
}

// ======================================
// Generate Mock Test via AI
// ======================================

async function generateMockTest() {
    const subject = document.getElementById("subject").value;
    const difficulty = document.getElementById("difficulty").value;
    const resultContainer = document.getElementById("studyPlan");

    if (!subject) {
        alert("Please specify a subject name.");
        return;
    }

    resultContainer.innerHTML = "<h2>Generating Examination Paper...</h2><p>AI is writing custom mock questions and answer keys. Please wait.</p>";
    resultContainer.style.display = "block";

    try {
        const response = await fetch(`${API_BASE_URL}/generate_mock_test`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                subject: subject,
                difficulty: difficulty
            })
        });

        const data = await response.json();
        if (data.success) {
            const formattedMock = data.mock_test.replace(/\n/g, "<br>");
            resultContainer.innerHTML = `
                <h2>Mock Examination: ${subject}</h2>
                <p><strong>Difficulty Level:</strong> ${difficulty.toUpperCase()}</p>
                <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
                <div class="plan-content" style="line-height: 1.6; text-align: left;">
                    ${formattedMock}
                </div>
            `;
        } else {
            resultContainer.innerHTML = `<h2>Error</h2><p>${data.message}</p>`;
        }
    } catch (error) {
        console.error("Mock test generation error:", error);
        resultContainer.innerHTML = "<h2>Error</h2><p>Unable to connect to backend server.</p>";
    }
}

// ======================================
// Days Remaining Calculation
// ======================================

function calculateDaysRemaining(examDate) {
    const today = new Date();
    const exam = new Date(examDate);
    const difference = exam - today;
    return Math.max(Math.ceil(difference / (1000 * 60 * 60 * 24)), 0);
}

// ======================================
// Save Study Plan
// ======================================

function savePlan(subject, examDate, studyPlanText) {
    const plan = {
        subject,
        examDate,
        studyPlanText,
        createdAt: new Date().toISOString()
    };
    localStorage.setItem("studyPlan", JSON.stringify(plan));
}

// ======================================
// Load Saved Study Plan
// ======================================

function loadSavedPlan() {
    const savedPlan = JSON.parse(localStorage.getItem("studyPlan"));
    if (!savedPlan) return;

    const resultContainer = document.getElementById("studyPlan");
    if (resultContainer) {
        const formattedPlan = savedPlan.studyPlanText.replace(/\n/g, "<br>");
        resultContainer.innerHTML = `
            <h2>Saved Study Plan</h2>
            <p><strong>Subject:</strong> ${savedPlan.subject}</p>
            <p><strong>Exam Date:</strong> ${savedPlan.examDate}</p>
            <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
            <div class="plan-content" style="line-height: 1.6; text-align: left;">
                ${formattedPlan}
            </div>
        `;
        resultContainer.style.display = "block";
    }
}

// ======================================
// Clear Study Plan
// ======================================

function clearStudyPlan() {
    localStorage.removeItem("studyPlan");
    const resultContainer = document.getElementById("studyPlan");
    if (resultContainer) {
        resultContainer.innerHTML = "";
        resultContainer.style.display = "none";
    }
    const examForm = document.getElementById("examForm");
    if (examForm) {
        examForm.reset();
    }
    alert("Study plan removed successfully.");
}