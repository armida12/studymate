﻿// ======================================
// StudyMate AI - Settings
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {

    // Login guard
    if (localStorage.getItem("isLoggedIn") !== "true") {
        window.location.href = "login.html";
        return;
    }

    loadAllSettings();
});

// ======================================
// Load all saved settings on page open
// ======================================

function loadAllSettings() {
    const user = JSON.parse(localStorage.getItem("currentUser") || "{}");

    // Profile fields
    const el = (id) => document.getElementById(id);
    if (el("settingName"))     el("settingName").value     = user.name  || "";
    if (el("settingEmail"))    el("settingEmail").value    = user.email || "";

    // Extended profile from local storage
    const profile = JSON.parse(localStorage.getItem("studentProfile") || "{}");
    if (el("settingCollege"))  el("settingCollege").value  = profile.college  || "";
    if (el("settingCourse"))   el("settingCourse").value   = profile.course   || "";
    if (el("settingSemester")) el("settingSemester").value = profile.year     || "";
    if (el("settingPhone"))    el("settingPhone").value    = user.phone || profile.phone || "";

    // App preferences
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    if (el("theme"))               el("theme").value                    = prefs.theme               || "light";
    if (el("fontSize"))            el("fontSize").value                 = prefs.fontSize            || "medium";
    if (el("aiResponseStyle"))     el("aiResponseStyle").value          = prefs.aiResponseStyle     || "balanced";
    if (el("preferredLanguage"))   el("preferredLanguage").value        = prefs.preferredLanguage   || "English";
    if (el("emailNotifications"))  el("emailNotifications").checked     = prefs.emailNotifications  ?? true;
    if (el("studyReminder"))       el("studyReminder").checked          = prefs.studyReminder       ?? true;
    if (el("examAlerts"))          el("examAlerts").checked             = prefs.examAlerts          ?? false;
    if (el("rememberConversations")) el("rememberConversations").checked = prefs.rememberConversations ?? true;
    if (el("voiceAssistant"))      el("voiceAssistant").checked         = prefs.voiceAssistant      ?? false;

    applyTheme();
    applyFontSize();

    // Fetch from backend if logged in
    if (user.id) fetchBackendSettings(user.id);
}

// ======================================
// Fetch settings from backend
// ======================================

async function fetchBackendSettings(userId) {
    try {
        const res  = await fetch(`${API_BASE_URL}/settings/${userId}`);
        const data = await res.json();
        if (data.success && data.settings) {
            const s = data.settings;
            const el = (id) => document.getElementById(id);
            if (s.theme              && el("theme"))             el("theme").value           = s.theme;
            if (s.preferred_language && el("preferredLanguage")) el("preferredLanguage").value = s.preferred_language;
            if (s.ai_response_style  && el("aiResponseStyle"))   el("aiResponseStyle").value  = s.ai_response_style;
            if (el("emailNotifications")) el("emailNotifications").checked = !!s.email_notifications;
            if (el("studyReminder"))      el("studyReminder").checked      = !!s.notifications_enabled;
            applyTheme();
        }
    } catch (_) { /* ignore network errors — use local storage */ }
}

// ======================================
// Save profile information
// ======================================

async function saveProfileSettings() {
    const user   = JSON.parse(localStorage.getItem("currentUser") || "{}");
    const el     = (id) => document.getElementById(id);
    const name   = el("settingName")?.value.trim();
    const phone  = el("settingPhone")?.value.trim();

    // Save extended fields locally
    const profile = JSON.parse(localStorage.getItem("studentProfile") || "{}");
    profile.college = el("settingCollege")?.value.trim() || "";
    profile.course  = el("settingCourse")?.value.trim()  || "";
    profile.year    = el("settingSemester")?.value.trim() || "";
    profile.phone   = phone;
    localStorage.setItem("studentProfile", JSON.stringify(profile));

    if (!user.id) {
        alert("Profile saved locally.");
        return;
    }

    try {
        const res  = await fetch(`${API_BASE_URL}/update_profile`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_id: user.id, name, phone, bio: user.bio || "" })
        });
        const data = await res.json();
        if (data.success) {
            user.name  = name;
            user.phone = phone;
            localStorage.setItem("currentUser", JSON.stringify(user));
            showToast("Profile saved successfully!");
        } else {
            alert("Error: " + data.message);
        }
    } catch (e) {
        alert("Saved locally (server offline).");
    }
}

// ======================================
// Change Password (client-side only validation)
// ======================================

function changePassword() {
    const cur  = document.getElementById("currentPassword")?.value;
    const nw   = document.getElementById("newPassword")?.value;
    const conf = document.getElementById("confirmPassword")?.value;
    if (!cur || !nw || !conf) { alert("Please fill all password fields."); return; }
    if (nw !== conf)           { alert("New passwords do not match.");       return; }
    if (nw.length < 6)         { alert("Password must be at least 6 characters."); return; }
    // In a real app call the backend change-password endpoint here
    alert("Password change is not yet connected to backend. Coming soon!");
}

// ======================================
// Save notification settings
// ======================================

async function saveNotificationSettings() {
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    prefs.emailNotifications = document.getElementById("emailNotifications")?.checked ?? true;
    prefs.studyReminder      = document.getElementById("studyReminder")?.checked      ?? true;
    prefs.examAlerts         = document.getElementById("examAlerts")?.checked         ?? false;
    localStorage.setItem("studyMateSettings", JSON.stringify(prefs));

    await pushSettingsToBackend(prefs);
    showToast("Notification preferences saved!");
}

// ======================================
// Save AI settings
// ======================================

async function saveAISettings() {
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    prefs.aiResponseStyle      = document.getElementById("aiResponseStyle")?.value      || "balanced";
    prefs.rememberConversations = document.getElementById("rememberConversations")?.checked ?? true;
    prefs.voiceAssistant       = document.getElementById("voiceAssistant")?.checked    ?? false;
    localStorage.setItem("studyMateSettings", JSON.stringify(prefs));

    await pushSettingsToBackend(prefs);
    showToast("AI preferences saved!");
}

// ======================================
// Save language settings
// ======================================

async function saveLanguageSettings() {
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    prefs.preferredLanguage = document.getElementById("preferredLanguage")?.value || "English";
    localStorage.setItem("studyMateSettings", JSON.stringify(prefs));

    await pushSettingsToBackend(prefs);
    showToast("Language preference saved!");
}

// ======================================
// Push preferences to backend
// ======================================

async function pushSettingsToBackend(prefs) {
    const user = JSON.parse(localStorage.getItem("currentUser") || "{}");
    if (!user.id) return;
    try {
        await fetch(`${API_BASE_URL}/settings/update`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                user_id:              user.id,
                theme:                prefs.theme               || "light",
                notifications_enabled: prefs.studyReminder      ?? true,
                email_notifications:  prefs.emailNotifications  ?? true,
                preferred_language:   prefs.preferredLanguage   || "English",
                ai_response_style:    prefs.aiResponseStyle     || "balanced"
            })
        });
    } catch (_) { /* silent */ }
}

// ======================================
// Apply theme
// ======================================

function applyTheme() {
    const theme = document.getElementById("theme")?.value || localStorage.getItem("theme") || "light";
    document.body.classList.toggle("dark-mode", theme === "dark");
    localStorage.setItem("theme", theme);
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    prefs.theme = theme;
    localStorage.setItem("studyMateSettings", JSON.stringify(prefs));
}

// ======================================
// Apply font size
// ======================================

function applyFontSize() {
    const sizes = { small: "14px", medium: "16px", large: "18px" };
    const val   = document.getElementById("fontSize")?.value || "medium";
    document.body.style.fontSize = sizes[val] || "16px";
    const prefs = JSON.parse(localStorage.getItem("studyMateSettings") || "{}");
    prefs.fontSize = val;
    localStorage.setItem("studyMateSettings", JSON.stringify(prefs));
}

// ======================================
// Clear all local data
// ======================================

function clearAllData() {
    if (confirm("This will clear all your local settings and progress. Are you sure?")) {
        const keys = ["studyMateSettings","studentProfile","studyProgress","chatHistory","generatedResume","studyPlan","profilePicture"];
        keys.forEach(k => localStorage.removeItem(k));
        alert("All local data cleared.");
        location.reload();
    }
}

// ======================================
// Logout
// ======================================

function logout() {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
    window.location.href = "login.html";
}

// ======================================
// Toast notification helper
// ======================================

function showToast(message) {
    const existing = document.getElementById("settingsToast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "settingsToast";
    toast.textContent = message;
    toast.style.cssText = "position:fixed;bottom:25px;right:25px;background:#6f42c1;color:white;padding:12px 22px;border-radius:8px;font-family:Poppins,sans-serif;font-size:14px;box-shadow:0 4px 15px rgba(0,0,0,0.2);z-index:9999;";
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
