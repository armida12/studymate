/* Theme Button */

.theme-btn {
    border: none;
    background: transparent;
    font-size: 24px;
    cursor: pointer;
    transition: 0.3s;
}

.theme-btn:hover {
    transform: scale(1.1);
}

/* Dark Mode */

.dark-mode {
    background-color: #121212;
    color: #ffffff;
}

.dark-mode .navbar,
.dark-mode .feature-card,
.dark-mode .step,
.dark-mode .card {
    background-color: #1e1e1e;
    color: #ffffff;
}

.dark-mode .footer {
    background-color: #0f172a;
}

.dark-mode input,
.dark-mode textarea,
.dark-mode select {
    background-color: #2d2d2d;
    color: white;
    border: 1px solid #444;
}