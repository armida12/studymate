// ======================================
// StudyMate AI - Resume Builder
// ======================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
    // Force redirect to login if not logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    const resumeForm = document.getElementById("resumeForm");
    if (resumeForm) {
        resumeForm.addEventListener("submit", generateResume);
    }

    loadSavedResume();
});

// ======================================
// Generate Resume via AI Backend
// ======================================

async function generateResume(event) {
    event.preventDefault();

    // Personal Information
    const fullName = document.getElementById("fullName").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const location = document.getElementById("location").value;
    const linkedin = document.getElementById("linkedin").value;
    const github = document.getElementById("github").value;

    // Education
    const college = document.getElementById("college").value;
    const degree = document.getElementById("degree").value;
    const specialization = document.getElementById("specialization").value;
    const cgpa = document.getElementById("cgpa").value;
    const year = document.getElementById("year").value;

    // Skills, Projects, Experience, Certifications, Summary
    const skills = document.getElementById("skills").value;
    const projects = document.getElementById("projects").value;
    const experience = document.getElementById("experience").value;
    const certifications = document.getElementById("certifications").value;
    const summary = document.getElementById("summary").value;

    // Resume Preview Container
    const preview = document.getElementById("resumePreview");
    if (!preview) return;

    preview.innerHTML = `
        <h2>Generating your AI Resume...</h2>
        <p>Gemini AI is writing an ATS-friendly format. Please wait.</p>
    `;
    preview.style.display = "block";

    const educationStr = `${degree} in ${specialization}\n${college} (CGPA: ${cgpa}, Grad Year: ${year})`;

    try {
        const currentUser = JSON.parse(localStorage.getItem("currentUser"));
        const response = await fetch(`${API_BASE_URL}/generate_resume`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: currentUser ? currentUser.id : null,
                name: fullName,
                email: email,
                phone: phone,
                education: educationStr,
                skills: skills,
                projects: projects,
                experience: experience,
                certifications: certifications,
                career_goal: summary
            })
        });

        const data = await response.json();

        if (data.success) {
            const formattedResume = data.resume.replace(/\n/g, "<br>");
            preview.innerHTML = `
                <div class="resume-template" style="line-height: 1.6; font-family: 'Poppins', sans-serif;">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <h1 style="margin: 0 0 5px 0;">${fullName}</h1>
                        <p style="margin: 0; color: #666;">
                            ${email} | ${phone} | ${location}<br>
                            ${linkedin ? `LinkedIn: ${linkedin}` : ""} ${github ? ` | GitHub: ${github}` : ""}
                        </p>
                    </div>
                    <hr style="border: 0; border-top: 1px solid #ddd; margin: 20px 0;">
                    <div class="resume-body">
                        ${formattedResume}
                    </div>
                </div>
            `;
            
            localStorage.setItem("generatedResume", preview.innerHTML);
            alert("AI Resume generated successfully!");
        } else {
            preview.innerHTML = `<h2>Error</h2><p>${data.message}</p>`;
        }
    } catch (error) {
        console.error("Resume generation error:", error);
        preview.innerHTML = "<h2>Error</h2><p>Unable to connect to backend server. Please verify Flask is running.</p>";
    }
}

// ======================================
// Download Resume (Print layout)
// ======================================

function downloadResume() {
    const preview = document.getElementById("resumePreview");
    if (!preview || !preview.innerHTML.trim() || preview.style.display === "none") {
        alert("Please generate the resume first.");
        return;
    }

    // Hide other elements for printing
    window.print();
}

// ======================================
// Load Previous Resume
// ======================================

function loadSavedResume() {
    const savedResume = localStorage.getItem("generatedResume");
    if (savedResume) {
        const preview = document.getElementById("resumePreview");
        if (preview) {
            preview.innerHTML = savedResume;
            preview.style.display = "block";
        }
    }
}

// ======================================
// Clear Resume
// ======================================

function clearResume() {
    localStorage.removeItem("generatedResume");
    const preview = document.getElementById("resumePreview");
    if (preview) {
        preview.innerHTML = "";
        preview.style.display = "none";
    }
    const resumeForm = document.getElementById("resumeForm");
    if (resumeForm) {
        resumeForm.reset();
    }
    alert("Resume cleared successfully.");
}