// =====================================
// StudyMate AI - Chat JavaScript
// =====================================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
    // Force redirect to login if not logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    const sendBtn = document.getElementById("sendButton");
    const userInput = document.getElementById("messageInput");

    if (sendBtn) {
        sendBtn.addEventListener("click", sendMessage);
    }

    if (userInput) {
        userInput.addEventListener("keypress", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                sendMessage();
            }
        });
    }

    loadChatHistory();
});

// =====================================
// Send Message
// =====================================

async function sendMessage() {
    const inputField = document.getElementById("messageInput");
    if (!inputField) return;

    const message = inputField.value.trim();
    if (message === "") return;

    addMessage(message, "user");
    inputField.value = "";
    showTypingIndicator();

    try {
        const currentUser = JSON.parse(localStorage.getItem("currentUser"));
        const response = await fetch(`${API_BASE_URL}/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                user_id: currentUser ? currentUser.id : null,
                message: message
            })
        });

        const data = await response.json();
        removeTypingIndicator();

        if (data.success) {
            addMessage(data.response, "bot");
            saveChatHistory(message, data.response);
        } else {
            // Show actual backend error so the user/developer can diagnose
            const errMsg = data.message || "An unknown error occurred on the server.";
            console.error("Backend error:", errMsg);
            addMessage(`⚠️ Server error: ${errMsg}`, "bot");
        }
    } catch (error) {
        console.error("Chat fetch error:", error);
        removeTypingIndicator();
        if (error instanceof TypeError) {
            addMessage("❌ Cannot reach the server. Make sure the Flask backend is running on port 5000.", "bot");
        } else {
            addMessage("❌ Unexpected error: " + error.message, "bot");
        }
    }
}

// =====================================
// Add Message to Chat Window
// =====================================

function addMessage(text, sender) {
    const chatBox = document.getElementById("chatMessages");
    if (!chatBox) return;

    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message");
    
    if (sender === "user") {
        messageDiv.classList.add("user-message");
    } else {
        messageDiv.classList.add("ai-message");
    }

    const currentTime = new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
    });

    const avatarHtml = sender === "user" 
        ? `<img src="assets/images/user-avatar.png" class="avatar" alt="User">`
        : `<img src="assets/images/ai-avatar.png" class="avatar" alt="AI">`;

    const titleHtml = sender === "user" ? "" : `<h4>StudyMate AI</h4>`;

    if (sender === "user") {
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${text}</p>
                <span class="message-time">${currentTime}</span>
            </div>
            ${avatarHtml}
        `;
    } else {
        messageDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                ${titleHtml}
                <p>${text}</p>
                <span class="message-time">${currentTime}</span>
            </div>
        `;
    }

    chatBox.appendChild(messageDiv);
    scrollToBottom();
}

// =====================================
// Typing Indicator
// =====================================

function showTypingIndicator() {
    const chatBox = document.getElementById("chatMessages");
    if (!chatBox) return;

    const typingDiv = document.createElement("div");
    typingDiv.id = "typingIndicator";
    typingDiv.classList.add("message", "ai-message");

    typingDiv.innerHTML = `
        <img src="assets/images/ai-avatar.png" class="avatar" alt="AI">
        <div class="message-content">
            <h4>StudyMate AI</h4>
            <p>StudyMate AI is typing...</p>
        </div>
    `;

    chatBox.appendChild(typingDiv);
    scrollToBottom();
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById("typingIndicator");
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

// =====================================
// Auto Scroll
// =====================================

function scrollToBottom() {
    const chatBox = document.getElementById("chatMessages");
    if (chatBox) {
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

// =====================================
// Save Chat History
// =====================================

function saveChatHistory(question, answer) {
    let history = JSON.parse(localStorage.getItem("chatHistory")) || [];
    history.push({
        question: question,
        answer: answer,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem("chatHistory", JSON.stringify(history));
}

// =====================================
// Load Previous Chat History
// =====================================

function loadChatHistory() {
    const history = JSON.parse(localStorage.getItem("chatHistory")) || [];
    const chatBox = document.getElementById("chatMessages");
    if (chatBox) {
        // Clear any hardcoded messages first
        chatBox.innerHTML = "";
        
        // Always add welcome message
        const welcomeDiv = document.createElement("div");
        welcomeDiv.classList.add("message", "ai-message");
        welcomeDiv.innerHTML = `
            <img src="assets/images/ai-avatar.png" class="avatar" alt="AI">
            <div class="message-content">
                <h4>StudyMate AI</h4>
                <p>Hello! 👋 I'm your AI Study Assistant. I can explain concepts, generate quizzes, summarize PDFs, create study plans and help with assignments.</p>
            </div>
        `;
        chatBox.appendChild(welcomeDiv);
    }
    
    history.forEach(chat => {
        addMessage(chat.question, "user");
        addMessage(chat.answer, "bot");
    });
}

// =====================================
// Clear Chat
// =====================================

function clearChat() {
    const chatBox = document.getElementById("chatMessages");
    if (chatBox) {
        chatBox.innerHTML = "";
        // Re-add welcome message
        const welcomeDiv = document.createElement("div");
        welcomeDiv.classList.add("message", "ai-message");
        welcomeDiv.innerHTML = `
            <img src="assets/images/ai-avatar.png" class="avatar" alt="AI">
            <div class="message-content">
                <h4>StudyMate AI</h4>
                <p>Hello! 👋 I'm your AI Study Assistant. I can explain concepts, generate quizzes, summarize PDFs, create study plans and help with assignments.</p>
            </div>
        `;
        chatBox.appendChild(welcomeDiv);
    }
    localStorage.removeItem("chatHistory");
}

// =====================================
// Voice Input
// =====================================

function startVoiceInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert("Voice recognition is not supported in this browser.");
        return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        const messageInput = document.getElementById("messageInput");
        if (messageInput) {
            messageInput.value = transcript;
        }
    };

    recognition.onerror = function() {
        alert("Voice recognition failed.");
    };
}