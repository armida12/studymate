// =====================================
// StudyMate AI - Register JavaScript
// =====================================

const API_BASE_URL = "http://127.0.0.1:5000";



document.addEventListener("DOMContentLoaded", () => {

    const registerForm =
        document.getElementById("registerForm");

    const passwordInput =
        document.getElementById("password");

    const confirmPasswordInput =
        document.getElementById("confirmPassword");

    const togglePassword =
        document.getElementById("togglePassword");

    const toggleConfirmPassword =
        document.getElementById(
            "toggleConfirmPassword"
        );

    // =====================================
    // Show / Hide Password
    // =====================================

    if (togglePassword && passwordInput) {

        togglePassword.addEventListener(
            "click",
            () => {

                const type =
                    passwordInput.type === "password"
                        ? "text"
                        : "password";

                passwordInput.type = type;

                togglePassword.classList.toggle(
                    "fa-eye"
                );

                togglePassword.classList.toggle(
                    "fa-eye-slash"
                );

            }
        );

    }

    if (
        toggleConfirmPassword &&
        confirmPasswordInput
    ) {

        toggleConfirmPassword.addEventListener(
            "click",
            () => {

                const type =
                    confirmPasswordInput.type === "password"
                        ? "text"
                        : "password";

                confirmPasswordInput.type = type;

                toggleConfirmPassword.classList.toggle(
                    "fa-eye"
                );

                toggleConfirmPassword.classList.toggle(
                    "fa-eye-slash"
                );

            }
        );

    }

    // =====================================
    // Register Form Submission
    // =====================================

    if (registerForm) {

        registerForm.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();

                const name =
                    document.getElementById(
                        "name"
                    ).value.trim();

                const email =
                    document.getElementById(
                        "email"
                    ).value.trim();

                const password =
                    passwordInput.value.trim();

                const confirmPassword =
                    confirmPasswordInput.value.trim();

                // =========================
                // Validation
                // =========================

                if (
                    !name ||
                    !email ||
                    !password ||
                    !confirmPassword
                ) {

                    alert(
                        "Please fill in all fields."
                    );

                    return;
                }

                if (name.length < 3) {

                    alert(
                        "Name must contain at least 3 characters."
                    );

                    return;
                }

                if (!validateEmail(email)) {

                    alert(
                        "Please enter a valid email address."
                    );

                    return;
                }

                if (password.length < 6) {

                    alert(
                        "Password must contain at least 6 characters."
                    );

                    return;
                }

                if (!containsNumber(password)) {

                    alert(
                        "Password must contain at least one number."
                    );

                    return;
                }

                if (
                    password !== confirmPassword
                ) {

                    alert(
                        "Passwords do not match."
                    );

                    return;
                }

                try {

                    const response =
                        await fetch(
                            `${API_BASE_URL}/register`,
                            
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body: JSON.stringify({
                                    name: name,
                                    email: email,
                                    password: password
                                })
                            }
                        );

                    if (!response.ok) {

                        throw new Error(
                            `Server Error: ${response.status}`
                        );

                    }

                    const data =
                        await response.json();

                    // =====================
                    // Registration Success
                    // =====================

                    if (data.success) {

                        alert(
                            "Registration successful!"
                        );

                        window.location.href =
                            "login.html";

                    }

                    // =====================
                    // Registration Failed
                    // =====================

                    else {

                       alert(
                            data.message ||
                            "Registration failed."
                        );

                    }

                }

               catch (error) {
    console.error("Registration Error:", error);

    alert(
       `Registration failed:\n${error.message}`
    );
}

            }
        );

    }

});

// =====================================
// Email Validation
// =====================================

function validateEmail(email) {

    const regex =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return regex.test(email);

}

// =====================================
// Password Validation
// =====================================

function containsNumber(password) {

    return /\d/.test(password);

}