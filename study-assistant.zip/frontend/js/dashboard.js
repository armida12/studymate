// ===============================
// StudyMate AI Dashboard JavaScript
// ===============================

const API_BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
    // Force redirect to login if not logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        window.location.href = "login.html";
        return;
    }

    loadUserData();
    displayCurrentDate();
    loadMotivationalQuote();
    initializeQuickActions();
});

// ===============================
// Load User Information & Progress
// ===============================

async function loadUserData() {
    const currentUser = localStorage.getItem("currentUser");
    const userNameElement = document.getElementById("userName");

    if (!currentUser) return;

    let user = null;
    try {
        user = JSON.parse(currentUser);
        if (userNameElement && user && user.name) {
            userNameElement.textContent = user.name;
        }
    } catch (e) {
        console.error("Error parsing user data:", e);
        if (userNameElement) userNameElement.textContent = "Student";
    }

    if (user && user.id) {
        try {
            const response = await fetch(`${API_BASE_URL}/progress/${user.id}`);
            const data = await response.json();
            if (data.success) {
                updateDashboardStats(data.progress);
            }
        } catch (error) {
            console.error("Failed to load user progress from server:", error);
            // Fall back to local storage or static defaults
            updateDashboardStats({
                total_quizzes: parseInt(localStorage.getItem("completedQuizzes")) || 18,
                average_score: parseFloat(localStorage.getItem("lastQuizScore")) || 87,
                subjects_studied: 25,
                recent_quizzes: []
            });
        }
    }
}

// ===============================
// Display Current Date
// ===============================

function displayCurrentDate() {
    const dateElement = document.getElementById("currentDate");
    if (!dateElement) return;

    const today = new Date();
    const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };

    dateElement.textContent = today.toLocaleDateString("en-US", options);
}

// ===============================
// Update Dashboard Statistics
// ===============================

function updateDashboardStats(progress) {
    const streakElement = document.getElementById("studyStreak");
    const completedTopicsElement = document.getElementById("completedTopics");
    const quizzesCompletedElement = document.getElementById("quizzesCompleted");
    const averageScoreElement = document.getElementById("averageScore");
    const progressBar = document.getElementById("progressBar");
    const progressText = document.getElementById("progressText");

    const streak = localStorage.getItem("studyStreak") || "12 Days";
    if (streakElement) {
        streakElement.textContent = streak.includes("Days") ? streak : `${streak} Days`;
    }

    if (completedTopicsElement) {
        completedTopicsElement.textContent = progress.subjects_studied || 0;
    }

    if (quizzesCompletedElement) {
        quizzesCompletedElement.textContent = progress.total_quizzes || 0;
    }

    if (averageScoreElement) {
        averageScoreElement.textContent = `${progress.average_score || 0}%`;
    }

    // Update study progress bar based on average score or progress
    const progressPercentage = progress.average_score || 0;
    if (progressBar) {
        progressBar.style.width = `${progressPercentage}%`;
    }
    if (progressText) {
        progressText.textContent = `${progressPercentage}% Score Avg`;
    }

    // Update recent activity list if elements exist
    const recentActivityList = document.getElementById("recentActivityList");
    if (recentActivityList && progress.recent_quizzes && progress.recent_quizzes.length > 0) {
        recentActivityList.innerHTML = "";
        progress.recent_quizzes.forEach(quiz => {
            const li = document.createElement("li");
            li.textContent = `✔ Took quiz on ${quiz.topic}: ${quiz.score}/${quiz.total_questions}`;
            recentActivityList.appendChild(li);
        });
    }
}

// ===============================
// Motivational Quotes
// ===============================

function loadMotivationalQuote() {
    const quotes = [
        "Success is the sum of small efforts repeated daily.",
        "Consistency beats intensity.",
        "Your future depends on what you do today.",
        "Learning never exhausts the mind.",
        "The expert in anything was once a beginner."
    ];

    const quoteElement = document.getElementById("dailyQuote");
    if (quoteElement) {
        const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
        quoteElement.textContent = `"${randomQuote}"`;
    }
}

// ===============================
// Quick Actions
// ===============================

function initializeQuickActions() {
    const actions = {
        startChat: "chat.html",
        generateQuiz: "quiz.html",
        examPrep: "exam.html",
        resumeBuilder: "resume.html",
        progressTracker: "progress.html"
    };

    Object.keys(actions).forEach(buttonId => {
        const button = document.getElementById(buttonId);
        if (button) {
            button.addEventListener("click", () => {
                window.location.href = actions[buttonId];
            });
        }
    });
}

// ===============================
// Logout
// ===============================

function logout() {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
    window.location.href = "login.html";
}