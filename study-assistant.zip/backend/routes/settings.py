from flask import Blueprint, request, jsonify
from config import get_db_connection

settings_bp = Blueprint("settings", __name__)

# =====================================
# Get User Settings
# =====================================

@settings_bp.route(
    "/settings/<int:user_id>",
    methods=["GET"]
)
def get_settings(user_id):

    try:

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            """
            SELECT
                theme,
                notifications_enabled,
                email_notifications,
                preferred_language,
                ai_response_style
            FROM user_settings
            WHERE user_id = %s
            """,
            (user_id,)
        )

        settings = cursor.fetchone()

        cursor.close()
        conn.close()

        if not settings:

            return jsonify({
                "success": True,
                "settings": {
                    "theme": "light",
                    "notifications_enabled": True,
                    "email_notifications": False,
                    "preferred_language": "English",
                    "ai_response_style": "balanced"
                }
            })

        return jsonify({
            "success": True,
            "settings": settings
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# =====================================
# Update User Settings
# =====================================

@settings_bp.route(
    "/settings/update",
    methods=["PUT"]
)
def update_settings():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        theme = data.get("theme")
        notifications_enabled = data.get(
            "notifications_enabled"
        )
        email_notifications = data.get(
            "email_notifications"
        )
        preferred_language = data.get(
            "preferred_language"
        )
        ai_response_style = data.get(
            "ai_response_style"
        )

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if settings already exist

        cursor.execute(
            """
            SELECT id
            FROM user_settings
            WHERE user_id = %s
            """,
            (user_id,)
        )

        existing = cursor.fetchone()

        if existing:

            cursor.execute(
                """
                UPDATE user_settings
                SET
                    theme = %s,
                    notifications_enabled = %s,
                    email_notifications = %s,
                    preferred_language = %s,
                    ai_response_style = %s
                WHERE user_id = %s
                """,
                (
                    theme,
                    notifications_enabled,
                    email_notifications,
                    preferred_language,
                    ai_response_style,
                    user_id
                )
            )

        else:

            cursor.execute(
                """
                INSERT INTO user_settings
                (
                    user_id,
                    theme,
                    notifications_enabled,
                    email_notifications,
                    preferred_language,
                    ai_response_style
                )
                VALUES (%s,%s,%s,%s,%s,%s)
                """,
                (
                    user_id,
                    theme,
                    notifications_enabled,
                    email_notifications,
                    preferred_language,
                    ai_response_style
                )
            )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "message":
                "Settings updated successfully"
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500