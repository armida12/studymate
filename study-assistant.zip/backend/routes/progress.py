from flask import Blueprint, jsonify
from config import get_db_connection

progress_bp = Blueprint("progress", __name__)

# ======================================
# Get User Progress Dashboard
# ======================================

@progress_bp.route(
    "/progress/<int:user_id>",
    methods=["GET"]
)
def get_progress(user_id):

    try:

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # --------------------------------
        # Total quizzes attempted
        # --------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_quizzes
            FROM quiz_results
            WHERE user_id = %s
            """,
            (user_id,)
        )

        total_quizzes = cursor.fetchone()["total_quizzes"]

        # --------------------------------
        # Average quiz score
        # --------------------------------

        cursor.execute(
            """
            SELECT AVG(
                (score * 100.0) /
                total_questions
            ) AS average_score
            FROM quiz_results
            WHERE user_id = %s
            """,
            (user_id,)
        )

        average_score = (
            cursor.fetchone()["average_score"] or 0
        )

        # --------------------------------
        # Total AI chat messages
        # --------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total_messages
            FROM chat_history
            WHERE user_id = %s
            """,
            (user_id,)
        )

        total_messages = cursor.fetchone()["total_messages"]

        # --------------------------------
        # Subjects studied
        # --------------------------------

        cursor.execute(
            """
            SELECT COUNT(
                DISTINCT topic
            ) AS subjects_studied
            FROM quiz_results
            WHERE user_id = %s
            """,
            (user_id,)
        )

        subjects_studied = cursor.fetchone()["subjects_studied"]

        # --------------------------------
        # Highest quiz score
        # --------------------------------

        cursor.execute(
            """
            SELECT MAX(
                (score * 100.0) /
                total_questions
            ) AS highest_score
            FROM quiz_results
            WHERE user_id = %s
            """,
            (user_id,)
        )

        highest_score = (
            cursor.fetchone()["highest_score"] or 0
        )

        # --------------------------------
        # Recent quiz history
        # --------------------------------

        cursor.execute(
            """
            SELECT
                topic,
                score,
                total_questions,
                created_at
            FROM quiz_results
            WHERE user_id = %s
            ORDER BY created_at DESC
            LIMIT 5
            """,
            (user_id,)
        )

        recent_quizzes = cursor.fetchall()

        cursor.close()
        conn.close()

        return jsonify({

            "success": True,

            "progress": {

                "total_quizzes":
                    total_quizzes,

                "average_score":
                    round(
                        average_score,
                        2
                    ),

                "highest_score":
                    round(
                        highest_score,
                        2
                    ),

                "total_messages":
                    total_messages,

                "subjects_studied":
                    subjects_studied,

                "recent_quizzes":
                    recent_quizzes
            }

        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500