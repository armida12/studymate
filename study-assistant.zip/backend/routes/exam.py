from flask import Blueprint, request, jsonify
from config import get_db_connection, model

exam_bp = Blueprint("exam", __name__)

# ======================================
# Generate Study Plan
# ======================================

@exam_bp.route(
    "/generate_study_plan",
    methods=["POST"]
)
def generate_study_plan():

    try:

        data = request.get_json()

        syllabus = data.get("syllabus")
        days_available = data.get(
            "days_available"
        )

        if not syllabus:
            return jsonify({
                "success": False,
                "message": "Syllabus is required."
            }), 400

        prompt = f"""
Create a study plan for the following syllabus.

Syllabus:
{syllabus}

Available days:
{days_available}

Requirements:
- Divide topics day by day
- Include revision sessions
- Include practice sessions
- Keep the plan realistic for a student
"""

        response = model.generate_content(
            prompt
        )

        return jsonify({
            "success": True,
            "study_plan": response.text
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ======================================
# Generate Important Questions
# ======================================

@exam_bp.route(
    "/important_questions",
    methods=["POST"]
)
def important_questions():

    try:

        data = request.get_json()

        subject = data.get("subject")
        syllabus = data.get("syllabus")

        prompt = f"""
Generate important exam questions for:

Subject:
{subject}

Syllabus:
{syllabus}

Include:
- Short questions
- Long questions
- Frequently repeated concepts
"""

        response = model.generate_content(
            prompt
        )

        return jsonify({
            "success": True,
            "questions": response.text
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ======================================
# Generate Mock Test
# ======================================

@exam_bp.route(
    "/generate_mock_test",
    methods=["POST"]
)
def generate_mock_test():

    try:

        data = request.get_json()

        subject = data.get("subject")
        difficulty = data.get(
            "difficulty",
            "medium"
        )

        prompt = f"""
Create a mock examination paper.

Subject:
{subject}

Difficulty:
{difficulty}

Requirements:
- 10 MCQ questions
- 5 short answer questions
- 2 long answer questions
- Include answer key at the end
"""

        response = model.generate_content(
            prompt
        )

        return jsonify({
            "success": True,
            "mock_test": response.text
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ======================================
# Save Study Progress
# ======================================

@exam_bp.route(
    "/save_exam_progress",
    methods=["POST"]
)
def save_exam_progress():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        subject = data.get("subject")
        completion = data.get("completion")

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO exam_progress
            (
                user_id,
                subject,
                completion_percentage
            )
            VALUES (%s,%s,%s)
            """,
            (
                user_id,
                subject,
                completion
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "message": "Progress saved."
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500