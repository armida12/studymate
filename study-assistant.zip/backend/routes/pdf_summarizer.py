﻿import os
from flask import Blueprint, request, jsonify
from openai import OpenAI, AuthenticationError, RateLimitError
from PyPDF2 import PdfReader

pdf_summarizer_bp = Blueprint("pdf_summarizer", __name__)

# Initialize OpenAI client — reads from env, falls back to key for dev
_API_KEY = os.getenv(
    "OPENAI_API_KEY",
    "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"
)
client = OpenAI(api_key=_API_KEY)


@pdf_summarizer_bp.route("/summarize_pdf", methods=["POST"])
def summarize_pdf():
    """Upload a PDF and return an AI-generated study summary."""
    if "file" not in request.files:
        return jsonify({"success": False, "message": "No file uploaded"}), 400

    file = request.files["file"]
    if not file or not file.filename.lower().endswith(".pdf"):
        return jsonify({"success": False, "message": "Please upload a valid PDF file"}), 400

    try:
        # Extract text from all pages
        reader = PdfReader(file)
        text_parts = []
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text_parts.append(extracted)
        full_text = "\n".join(text_parts).strip()

        if not full_text:
            return jsonify({"success": False, "message": "Could not extract readable text from this PDF. It may be scanned/image-based."}), 400

        # Truncate to stay within token limits (~12000 chars ~ 3000 tokens)
        if len(full_text) > 12000:
            full_text = full_text[:12000] + "\n\n[Document truncated for processing...]"

        # Call OpenAI API (v1 SDK style)
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert academic AI assistant. Summarize the following document "
                        "in a structured, student-friendly format. Include:\n"
                        "1. **Key Topics** - the main subjects covered\n"
                        "2. **Important Points** - concise bullet list of critical facts\n"
                        "3. **Definitions** - any technical terms and their meanings\n"
                        "4. **Exam Tips** - what a student should focus on for exams\n"
                        "Make the summary clear, concise and easy to study from."
                    )
                },
                {"role": "user", "content": f"Document Content:\n\n{full_text}"}
            ],
            max_tokens=700,
            temperature=0.4,
        )

        summary = response.choices[0].message.content.strip()
        return jsonify({"success": True, "summary": summary})

    except AuthenticationError:
        return jsonify({"success": False, "message": "Invalid OpenAI API key."}), 401
    except RateLimitError:
        return jsonify({"success": False, "message": "OpenAI rate limit reached. Try again in a moment."}), 429
    except Exception as e:
        return jsonify({"success": False, "message": f"Error processing PDF: {str(e)}"}), 500
