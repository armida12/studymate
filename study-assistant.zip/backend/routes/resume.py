from flask import Blueprint, request, jsonify
from config import get_db_connection, model

resume_bp = Blueprint("resume", __name__)

# ===================================
# Generate Resume
# ===================================

@resume_bp.route(
    "/generate_resume",
    methods=["POST"]
)
def generate_resume():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        name = data.get("name")
        email = data.get("email")
        phone = data.get("phone")
        education = data.get("education")
        skills = data.get("skills")
        projects = data.get("projects")
        experience = data.get("experience")
        certifications = data.get("certifications")
        career_goal = data.get("career_goal")

        prompt = f"""
Generate an ATS-friendly professional resume.

Name: {name}
Email: {email}
Phone: {phone}

Education:
{education}

Skills:
{skills}

Projects:
{projects}

Experience:
{experience}

Certifications:
{certifications}

Career Objective:
{career_goal}

Requirements:
- Professional formatting
- ATS friendly wording
- Strong action verbs
- Suitable for Indian college students
"""

        response = model.generate_content(
            prompt
        )

        generated_resume = response.text

        # Save to database

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO resumes
            (
                user_id,
                resume_content
            )
            VALUES (%s,%s)
            """,
            (
                user_id,
                generated_resume
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "resume": generated_resume
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ===================================
# Get Previously Generated Resumes
# ===================================

@resume_bp.route(
    "/get_resumes/<int:user_id>",
    methods=["GET"]
)
def get_resumes(user_id):

    try:

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            """
            SELECT id,
                   resume_content,
                   created_at
            FROM resumes
            WHERE user_id=%s
            ORDER BY created_at DESC
            """,
            (user_id,)
        )

        resumes = cursor.fetchall()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "resumes": resumes
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500