from flask import Blueprint, request, jsonify
import json
from config import get_db_connection, model

quiz_bp = Blueprint("quiz", __name__)

# ---------------------------------------
# Generate Quiz
# ---------------------------------------

@quiz_bp.route("/generate_quiz", methods=["POST"])
def generate_quiz():

    try:

        data = request.get_json()

        topic = data.get("topic")
        difficulty = data.get("difficulty", "medium")
        number_of_questions = data.get(
            "number_of_questions",
            5
        )

        if not topic:
            return jsonify({
                "success": False,
                "message": "Topic is required."
            }), 400

        prompt = f"""
Generate {number_of_questions} multiple choice questions on {topic}.

Difficulty level: {difficulty}

Return ONLY valid JSON using this format:

[
    {{
        "question": "Question text",
        "options": [
            "Option A",
            "Option B",
            "Option C",
            "Option D"
        ],
        "answer": "Correct Option"
    }}
]

Do not include markdown or explanations.
"""

        response = model.generate_content(prompt)

        quiz_text = response.text.strip()

        # Remove markdown if Gemini returns it
        quiz_text = quiz_text.replace(
            "```json",
            ""
        ).replace(
            "```",
            ""
        ).strip()

        questions = json.loads(quiz_text)

        return jsonify({
            "success": True,
            "questions": questions
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ---------------------------------------
# Submit Quiz Result
# ---------------------------------------

@quiz_bp.route("/submit_quiz", methods=["POST"])
def submit_quiz():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        topic = data.get("topic")
        score = data.get("score")
        total_questions = data.get(
            "total_questions"
        )

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO quiz_results
            (
                user_id,
                topic,
                score,
                total_questions
            )
            VALUES (%s, %s, %s, %s)
            """,
            (
                user_id,
                topic,
                score,
                total_questions
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "message": "Quiz result saved successfully."
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500