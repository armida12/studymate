from flask import Blueprint, request, jsonify
from config import get_db_connection

profile_bp = Blueprint("profile", __name__)

# =====================================
# Get User Profile
# =====================================

@profile_bp.route(
    "/profile/<int:user_id>",
    methods=["GET"]
)
def get_profile(user_id):

    try:

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            """
            SELECT
                id,
                name,
                email,
                phone,
                bio,
                profile_picture,
                created_at
            FROM users
            WHERE id = %s
            """,
            (user_id,)
        )

        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if not user:
            return jsonify({
                "success": False,
                "message": "User not found"
            }), 404

        return jsonify({
            "success": True,
            "profile": user
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# =====================================
# Update User Profile
# =====================================

@profile_bp.route(
    "/update_profile",
    methods=["PUT"]
)
def update_profile():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        name = data.get("name")
        phone = data.get("phone")
        bio = data.get("bio")

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE users
            SET
                name = %s,
                phone = %s,
                bio = %s
            WHERE id = %s
            """,
            (
                name,
                phone,
                bio,
                user_id
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "message": "Profile updated successfully"
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# =====================================
# Update Profile Picture
# =====================================

@profile_bp.route(
    "/update_profile_picture",
    methods=["POST"]
)
def update_profile_picture():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        profile_picture = data.get(
            "profile_picture"
        )

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE users
            SET profile_picture = %s
            WHERE id = %s
            """,
            (
                profile_picture,
                user_id
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "message":
                "Profile picture updated"
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "message": str(e)
        }), 500