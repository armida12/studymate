from flask import Blueprint, request, jsonify
import bcrypt
from config import get_db_connection

auth_bp = Blueprint('auth', __name__)


# -----------------------------------------
# Register User
# -----------------------------------------

@auth_bp.route('/register', methods=['POST'])
def register():

    data = request.get_json()

    name = data.get("name")
    email = data.get("email")
    password = data.get("password")

    if not name or not email or not password:
        return jsonify({
            "success": False,
            "message": "All fields are required."
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Check if email already exists
    cursor.execute(
        "SELECT * FROM users WHERE email = %s",
        (email,)
    )

    existing_user = cursor.fetchone()

    if existing_user:
        cursor.close()
        conn.close()

        return jsonify({
            "success": False,
            "message": "Email already exists."
        }), 409

    # Hash password
    hashed_password = bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt()
    )

    # Insert user
    cursor.execute(
     
     """
     INSERT INTO users (name, email, password)
        VALUES (%s, %s, %s)
        """
        ,
        (
            name,
            email,
            hashed_password.decode("utf-8")
        )
    )

    conn.commit()

    cursor.close()
    conn.close()

    return jsonify({
        "success": True,
        "message": "Registration successful."
    }), 201


# -----------------------------------------
# Login User
# -----------------------------------------

@auth_bp.route('/login', methods=['POST'])
def login():

    data = request.get_json()

    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({
            "success": False,
            "message": "Email and password are required."
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT * FROM users WHERE email = %s",
        (email,)
    )

    user = cursor.fetchone()

    cursor.close()
    conn.close()

    if not user:
        return jsonify({
            "success": False,
            "message": "Invalid email or password."
        }), 401

    stored_password = user["password"]

    if bcrypt.checkpw(
        password.encode("utf-8"),
        stored_password.encode("utf-8")
    ):

        return jsonify({
            "success": True,
            "message": "Login successful.",
            "user": {
                "id": user["id"],
                "name": user["name"],
                "email": user["email"]
            }
        }), 200

    return jsonify({
        "success": False,
        "message": "Invalid email or password."
    }), 401


# -----------------------------------------
# Logout User
# -----------------------------------------

@auth_bp.route('/logout', methods=['POST'])
def logout():

    return jsonify({
        "success": True,
        "message": "Logout successful."
    }), 200