from flask import Blueprint, request, jsonify
from config import get_db_connection, model

chat_bp = Blueprint("chat", __name__)

# ---------------------------------------
# Chat Route
# ---------------------------------------

@chat_bp.route("/chat", methods=["POST"])
def chat():

    try:

        data = request.get_json()

        user_id = data.get("user_id")
        message = data.get("message")

        if not message:
            return jsonify({
                "success": False,
                "message": "Message cannot be empty."
            }), 400

        # Generate AI response
        response = model.generate_content(message)

        ai_reply = response.text

        # Save chat history if user is logged in
        if user_id:

            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO chat_history
                (user_id, user_message, ai_response)
                VALUES (%s, %s, %s)
                """,
                (
                    user_id,
                    message,
                    ai_reply
                )
            )

            conn.commit()
            cursor.close()
            conn.close()

        return jsonify({
            "success": True,
            "response": ai_reply
        })

    except Exception as e:
        err_str = str(e)
        # Give a friendly message for quota/key issues instead of the raw API error
        if any(kw in err_str.lower() for kw in ["quota", "exhausted", "429", "api key", "unavailable", "not found", "no longer available"]):
            friendly = (
                "⚠️ The AI service is temporarily unavailable due to API quota limits. "
                "Please ask the administrator to update the Gemini API key at aistudio.google.com/apikey."
            )
            return jsonify({"success": False, "message": friendly}), 503
        return jsonify({"success": False, "message": err_str}), 500