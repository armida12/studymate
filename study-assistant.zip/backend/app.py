from flask import Flask
from flask_cors import CORS
from routes.auth import auth_bp
from routes.chat import chat_bp
from routes.quiz import quiz_bp
from routes.exam import exam_bp
from routes.profile import profile_bp
from routes.progress import progress_bp
from routes.resume import resume_bp
from routes.settings import settings_bp
from routes.pdf_summarizer import pdf_summarizer_bp

app = Flask(__name__)

CORS(app)
app.register_blueprint(auth_bp)
app.register_blueprint(chat_bp)
app.register_blueprint(quiz_bp)
app.register_blueprint(exam_bp)
app.register_blueprint(profile_bp)
app.register_blueprint(progress_bp)
app.register_blueprint(resume_bp)
app.register_blueprint(settings_bp)
app.register_blueprint(pdf_summarizer_bp)

@app.route("/")
def home():
    return {
        "message": "StudyMate AI Backend Running"
    }

if __name__ == "__main__":
    app.run(debug=True)

    