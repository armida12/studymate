import os
import mysql.connector
import sys

def main():
    db_host = os.getenv("DB_HOST", "localhost")
    db_user = os.getenv("DB_USER", "root")
    db_password = os.getenv("DB_PASSWORD", "mysql")
    db_name = os.getenv("DB_NAME", "studymate_ai")

    print(f"Connecting to MySQL ({db_host}) to set up database schema...")
    try:
        # Connect to MySQL server (without database first)
        conn = mysql.connector.connect(
            host=db_host,
            user=db_user,
            password=db_password
        )
        cursor = conn.cursor()
        
        # Create database if not exists
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        print(f"Database '{db_name}' ensured.")
        cursor.close()
        conn.close()

        # Connect to the studymate_ai database
        conn = mysql.connector.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name
        )
        cursor = conn.cursor()
        
        # Drop old tables that might conflict
        tables_to_drop = [
            "chat_history", "quiz_results", "resumes", "exam_progress", 
            "user_settings", "users", "profiles", "progress", 
            "quiz_questions", "quizzes", "exam_plans", "settings"
        ]
        
        print("Dropping old tables if they exist...")
        # Disable foreign key checks temporarily to drop cleanly
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        for table in tables_to_drop:
            cursor.execute(f"DROP TABLE IF EXISTS {table}")
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
        
        print("Creating table: users")
        cursor.execute("""
            CREATE TABLE users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100) UNIQUE,
                password VARCHAR(255),
                phone VARCHAR(20) NULL,
                bio TEXT NULL,
                profile_picture LONGTEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        print("Creating table: chat_history")
        cursor.execute("""
            CREATE TABLE chat_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                user_message TEXT,
                ai_response TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        print("Creating table: quiz_results")
        cursor.execute("""
            CREATE TABLE quiz_results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                topic VARCHAR(255),
                score INT,
                total_questions INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        print("Creating table: resumes")
        cursor.execute("""
            CREATE TABLE resumes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                resume_content LONGTEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        print("Creating table: exam_progress")
        cursor.execute("""
            CREATE TABLE exam_progress (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                subject VARCHAR(255),
                completion_percentage INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        print("Creating table: user_settings")
        cursor.execute("""
            CREATE TABLE user_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNIQUE,
                theme VARCHAR(20) DEFAULT 'light',
                notifications_enabled BOOLEAN DEFAULT TRUE,
                email_notifications BOOLEAN DEFAULT FALSE,
                preferred_language VARCHAR(50) DEFAULT 'English',
                ai_response_style VARCHAR(50) DEFAULT 'balanced',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        conn.commit()
        print("\nAll tables created successfully and match backend requirements!")
        cursor.close()
        conn.close()
    
    except mysql.connector.Error as err:
        print(f"Error executing database setup: {err}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
