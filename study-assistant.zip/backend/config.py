import os
import warnings
import mysql.connector

# -----------------------------------------
# Database Connection
# -----------------------------------------

def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", "mysql"),
        database=os.getenv("DB_NAME", "studymate_ai")
    )

# -----------------------------------------
# Gemini AI Configuration
# -----------------------------------------

GEMINI_API_KEY = "AQ.Ab8RN6LOhI_NT5IUQbjmJbAVkgZgB6Z-t1fCnd7doxEwVxeKag"

# Only models confirmed available to all users (no gemini-2.5-flash - not for new users)
GEMINI_MODELS = [
    "gemini-3.5-flash",
]

_genai_client = None

def _get_client():
    global _genai_client
    if _genai_client is not None:
        return _genai_client
    try:
        import importlib
        genai_mod = importlib.import_module("google.genai")
        _genai_client = genai_mod.Client(api_key=GEMINI_API_KEY)
    except Exception:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            import google.generativeai as g
            g.configure(api_key=GEMINI_API_KEY)
            _genai_client = g
    return _genai_client


# Errors that indicate we should try the next model instead of raising
_SKIP_KEYWORDS = [
    "quota", "exhausted", "rate limit", "429",
    "not found", "not_found", "404",
    "no longer available", "deprecated",
    "resource_exhausted"
]


def _should_skip(err: Exception) -> bool:
    msg = str(err).lower()
    return any(kw in msg for kw in _SKIP_KEYWORDS)


def generate_ai_response(prompt: str) -> str:
    """Generate a response, trying each model in order. Returns text string."""
    client = _get_client()

    if hasattr(client, "models"):
        # New google-genai SDK
        last_err = None
        for model_name in GEMINI_MODELS:
            try:
                resp = client.models.generate_content(
                    model=model_name,
                    contents=prompt
                )
                return resp.text
            except Exception as e:
                last_err = e
                if _should_skip(e):
                    continue
                raise e
        # All models skipped — report clearly
        raise RuntimeError(
            "All Gemini models are currently unavailable (quota exhausted or key issue). "
            "Please check your API key at https://aistudio.google.com/apikey or wait and retry."
        )
    else:
        # Old google-generativeai SDK fallback
        last_err = None
        for model_name in GEMINI_MODELS:
            try:
                m    = client.GenerativeModel(model_name)
                resp = m.generate_content(prompt)
                return resp.text
            except Exception as e:
                last_err = e
                if _should_skip(e):
                    continue
                raise e
        raise RuntimeError(
            "All Gemini models are currently unavailable. "
            "Please check your API key or wait before retrying."
        )


# Legacy alias so existing route files using model.generate_content(...) keep working
class _ModelCompat:
    def generate_content(self, prompt):
        class _R:
            pass
        r = _R()
        r.text = generate_ai_response(prompt)
        return r

model = _ModelCompat()
