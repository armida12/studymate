import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="mysql",
    database="studymate_ai"
)

cursor = connection.cursor()