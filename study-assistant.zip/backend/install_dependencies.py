import subprocess
import sys
import os

def install_package(package):
    print(f"Installing {package}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def main():
    print("Checking and installing backend dependencies...")
    
    # 1. Upgrade pip first
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    except Exception as e:
        print(f"Warning: Failed to upgrade pip: {e}")

    # 2. Install requirements.txt if it exists
    req_path = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if os.path.exists(req_path):
        print(f"Installing from requirements.txt: {req_path}")
        try:
            # Try installing with matching encoding
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", req_path])
        except Exception as e:
            print(f"Failed to install all packages from requirements.txt: {e}")
            print("Attempting to install core packages manually...")
            install_package("Flask==3.0.2")
            install_package("flask-cors==4.0.0")
            install_package("bcrypt==4.1.2")
            install_package("google-generativeai==0.4.0")
            install_package("PyPDF2==3.0.1")
            install_package("python-dotenv==1.0.1")

    # 3. Ensure required database connectors are installed
    try:
        import mysql.connector
        print("mysql-connector-python is already installed.")
    except ImportError:
        install_package("mysql-connector-python")

    # 4. Ensure bcrypt is installed
    try:
        import bcrypt
        print("bcrypt is already installed.")
    except ImportError:
        install_package("bcrypt")

    print("\nAll dependencies checked and installed successfully!")

if __name__ == "__main__":
    main()
