# ==========================================
# StudyMate AI - Quiz Model
# ==========================================

class QuizModel:

    # --------------------------------------
    # Create Quiz
    # --------------------------------------

    @staticmethod
    def create_quiz(
        mysql,
        user_id,
        topic,
        difficulty
    ):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO quizzes
            (
                user_id,
                topic,
                difficulty
            )
            VALUES
            (
                %s,
                %s,
                %s
            )
        """

        cursor.execute(
            query,
            (
                user_id,
                topic,
                difficulty
            )
        )

        mysql.connection.commit()

        quiz_id = cursor.lastrowid

        cursor.close()

        return quiz_id

    # --------------------------------------
    # Save Question
    # --------------------------------------

    @staticmethod
    def save_question(
        mysql,
        quiz_id,
        question,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer
    ):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO quiz_questions
            (
                quiz_id,
                question,
                option_a,
                option_b,
                option_c,
                option_d,
                correct_answer
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        cursor.execute(
            query,
            (
                quiz_id,
                question,
                option_a,
                option_b,
                option_c,
                option_d,
                correct_answer
            )
        )

        mysql.connection.commit()

        question_id = cursor.lastrowid

        cursor.close()

        return question_id

    # --------------------------------------
    # Save Quiz Result
    # --------------------------------------

    @staticmethod
    def save_result(
        mysql,
        quiz_id,
        user_id,
        score,
        total_questions
    ):

        percentage = (
            score / total_questions
        ) * 100

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO quiz_results
            (
                quiz_id,
                user_id,
                score,
                total_questions,
                percentage
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        cursor.execute(
            query,
            (
                quiz_id,
                user_id,
                score,
                total_questions,
                percentage
            )
        )

        mysql.connection.commit()

        result_id = cursor.lastrowid

        cursor.close()

        return result_id

    # --------------------------------------
    # Get Quiz Questions
    # --------------------------------------

    @staticmethod
    def get_questions(
        mysql,
        quiz_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                question,
                option_a,
                option_b,
                option_c,
                option_d,
                correct_answer
            FROM quiz_questions
            WHERE quiz_id = %s
        """

        cursor.execute(
            query,
            (quiz_id,)
        )

        questions = cursor.fetchall()

        cursor.close()

        return questions

    # --------------------------------------
    # Get User Quiz Results
    # --------------------------------------

    @staticmethod
    def get_user_results(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                score,
                total_questions,
                percentage,
                completed_at
            FROM quiz_results
            WHERE user_id = %s
            ORDER BY completed_at DESC
        """

        cursor.execute(
            query,
            (user_id,)
        )

        results = cursor.fetchall()

        cursor.close()

        return results