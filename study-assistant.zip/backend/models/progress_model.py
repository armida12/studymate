# ==========================================
# StudyMate AI - Progress Model
# ==========================================

class ProgressModel:

    # --------------------------------------
    # Create Progress Record
    # --------------------------------------

    @staticmethod
    def create_progress(mysql, user_id):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO progress
            (
                user_id
            )
            VALUES
            (
                %s
            )
        """

        cursor.execute(
            query,
            (user_id,)
        )

        mysql.connection.commit()

        progress_id = cursor.lastrowid

        cursor.close()

        return progress_id

    # --------------------------------------
    # Get User Progress
    # --------------------------------------

    @staticmethod
    def get_progress(mysql, user_id):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                total_study_hours,
                completed_topics,
                quizzes_attempted,
                average_quiz_score,
                current_streak,
                longest_streak,
                updated_at
            FROM progress
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        progress = cursor.fetchone()

        cursor.close()

        return progress

    # --------------------------------------
    # Update Study Hours
    # --------------------------------------

    @staticmethod
    def add_study_hours(
        mysql,
        user_id,
        hours
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE progress
            SET total_study_hours =
                total_study_hours + %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                hours,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Increment Completed Topics
    # --------------------------------------

    @staticmethod
    def add_completed_topic(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE progress
            SET completed_topics =
                completed_topics + 1
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Quiz Statistics
    # --------------------------------------

    @staticmethod
    def update_quiz_stats(
        mysql,
        user_id,
        new_score
    ):

        cursor = mysql.connection.cursor()

        # Get current values
        query = """
            SELECT
                quizzes_attempted,
                average_quiz_score
            FROM progress
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        result = cursor.fetchone()

        quizzes_attempted = result[0]
        average_score = result[1]

        new_attempts = quizzes_attempted + 1

        new_average = (
            (
                average_score *
                quizzes_attempted
            )
            + new_score
        ) / new_attempts

        update_query = """
            UPDATE progress
            SET
                quizzes_attempted = %s,
                average_quiz_score = %s
            WHERE user_id = %s
        """

        cursor.execute(
            update_query,
            (
                new_attempts,
                new_average,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Streak
    # --------------------------------------

    @staticmethod
    def update_streak(
        mysql,
        user_id,
        current_streak
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE progress
            SET
                current_streak = %s,
                longest_streak =
                    GREATEST(
                        longest_streak,
                        %s
                    )
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                current_streak,
                current_streak,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Reset Streak
    # --------------------------------------

    @staticmethod
    def reset_streak(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE progress
            SET current_streak = 0
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        mysql.connection.commit()

        cursor.close()