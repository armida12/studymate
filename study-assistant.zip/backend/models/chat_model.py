# ==========================================
# StudyMate AI - Chat Model
# ==========================================

class ChatModel:

    # --------------------------------------
    # Save chat message
    # --------------------------------------

    @staticmethod
    def save_chat(mysql, user_id, question, answer):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO chat_history
            (
                user_id,
                question,
                answer
            )
            VALUES
            (
                %s,
                %s,
                %s
            )
        """

        cursor.execute(
            query,
            (
                user_id,
                question,
                answer
            )
        )

        mysql.connection.commit()

        chat_id = cursor.lastrowid

        cursor.close()

        return chat_id

    # --------------------------------------
    # Get all chats of a user
    # --------------------------------------

    @staticmethod
    def get_user_chats(mysql, user_id):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                question,
                answer,
                created_at
            FROM chat_history
            WHERE user_id = %s
            ORDER BY created_at ASC
        """

        cursor.execute(
            query,
            (user_id,)
        )

        chats = cursor.fetchall()

        cursor.close()

        return chats

    # --------------------------------------
    # Get latest chats
    # --------------------------------------

    @staticmethod
    def get_recent_chats(
        mysql,
        user_id,
        limit=10
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                question,
                answer,
                created_at
            FROM chat_history
            WHERE user_id = %s
            ORDER BY created_at DESC
            LIMIT %s
        """

        cursor.execute(
            query,
            (
                user_id,
                limit
            )
        )

        chats = cursor.fetchall()

        cursor.close()

        return chats

    # --------------------------------------
    # Delete chat history
    # --------------------------------------

    @staticmethod
    def delete_user_chats(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            DELETE FROM chat_history
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        mysql.connection.commit()

        deleted_rows = cursor.rowcount

        cursor.close()

        return deleted_rows