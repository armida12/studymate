# ==========================================
# StudyMate AI - Profile Model
# ==========================================

class ProfileModel:

    # --------------------------------------
    # Create Profile
    # --------------------------------------

    @staticmethod
    def create_profile(
        mysql,
        user_id,
        full_name="",
        college="",
        course="",
        year_of_study="",
        skills="",
        learning_goals="",
        profile_image=""
    ):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO profiles
            (
                user_id,
                full_name,
                college,
                course,
                year_of_study,
                skills,
                learning_goals,
                profile_image
            )
            VALUES
            (
                %s, %s, %s, %s,
                %s, %s, %s, %s
            )
        """

        cursor.execute(
            query,
            (
                user_id,
                full_name,
                college,
                course,
                year_of_study,
                skills,
                learning_goals,
                profile_image
            )
        )

        mysql.connection.commit()

        profile_id = cursor.lastrowid

        cursor.close()

        return profile_id

    # --------------------------------------
    # Get Profile by User ID
    # --------------------------------------

    @staticmethod
    def get_profile(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                user_id,
                full_name,
                college,
                course,
                year_of_study,
                skills,
                learning_goals,
                profile_image,
                created_at,
                updated_at
            FROM profiles
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        profile = cursor.fetchone()

        cursor.close()

        return profile

    # --------------------------------------
    # Update Profile
    # --------------------------------------

    @staticmethod
    def update_profile(
        mysql,
        user_id,
        full_name,
        college,
        course,
        year_of_study,
        skills,
        learning_goals,
        profile_image
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE profiles
            SET
                full_name = %s,
                college = %s,
                course = %s,
                year_of_study = %s,
                skills = %s,
                learning_goals = %s,
                profile_image = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                full_name,
                college,
                course,
                year_of_study,
                skills,
                learning_goals,
                profile_image,
                user_id
            )
        )

        mysql.connection.commit()

        updated_rows = cursor.rowcount

        cursor.close()

        return updated_rows

    # --------------------------------------
    # Delete Profile
    # --------------------------------------

    @staticmethod
    def delete_profile(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            DELETE FROM profiles
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (user_id,)
        )

        mysql.connection.commit()

        deleted_rows = cursor.rowcount

        cursor.close()

        return deleted_rows