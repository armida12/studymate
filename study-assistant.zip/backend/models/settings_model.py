# ==========================================
# StudyMate AI - Settings Model
# ==========================================

class SettingsModel:

    # --------------------------------------
    # Create Default Settings
    # --------------------------------------

    @staticmethod
    def create_settings(mysql, user_id):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO settings (user_id)
            VALUES (%s)
        """

        cursor.execute(query, (user_id,))
        mysql.connection.commit()

        settings_id = cursor.lastrowid

        cursor.close()

        return settings_id

    # --------------------------------------
    # Get User Settings
    # --------------------------------------

    @staticmethod
    def get_settings(mysql, user_id):

        cursor = mysql.connection.cursor(dictionary=True)

        query = """
            SELECT *
            FROM settings
            WHERE user_id = %s
        """

        cursor.execute(query, (user_id,))

        settings = cursor.fetchone()

        cursor.close()

        return settings

    # --------------------------------------
    # Update Theme
    # --------------------------------------

    @staticmethod
    def update_theme(
        mysql,
        user_id,
        theme
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE settings
            SET theme = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                theme,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Notifications
    # --------------------------------------

    @staticmethod
    def update_notifications(
        mysql,
        user_id,
        notifications_enabled,
        email_notifications
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE settings
            SET
                notifications_enabled = %s,
                email_notifications = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                notifications_enabled,
                email_notifications,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Voice Assistant Setting
    # --------------------------------------

    @staticmethod
    def update_voice_setting(
        mysql,
        user_id,
        voice_enabled
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE settings
            SET voice_enabled = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                voice_enabled,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Language
    # --------------------------------------

    @staticmethod
    def update_language(
        mysql,
        user_id,
        language
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE settings
            SET language = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                language,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()

    # --------------------------------------
    # Update Reminder Time
    # --------------------------------------

    @staticmethod
    def update_reminder_time(
        mysql,
        user_id,
        reminder_time
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE settings
            SET reminder_time = %s
            WHERE user_id = %s
        """

        cursor.execute(
            query,
            (
                reminder_time,
                user_id
            )
        )

        mysql.connection.commit()

        cursor.close()