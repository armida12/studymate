# ==========================================
# StudyMate AI - Resume Model
# ==========================================

class ResumeModel:

    # --------------------------------------
    # Create Resume
    # --------------------------------------

    @staticmethod
    def create_resume(
        mysql,
        user_id,
        full_name,
        email,
        phone="",
        address="",
        summary="",
        education="",
        skills="",
        experience="",
        projects="",
        certifications=""
    ):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO resumes
            (
                user_id,
                full_name,
                email,
                phone,
                address,
                summary,
                education,
                skills,
                experience,
                projects,
                certifications
            )
            VALUES
            (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s
            )
        """

        cursor.execute(
            query,
            (
                user_id,
                full_name,
                email,
                phone,
                address,
                summary,
                education,
                skills,
                experience,
                projects,
                certifications
            )
        )

        mysql.connection.commit()

        resume_id = cursor.lastrowid

        cursor.close()

        return resume_id

    # --------------------------------------
    # Get Resume by User ID
    # --------------------------------------

    @staticmethod
    def get_resume(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor(dictionary=True)

        query = """
            SELECT *
            FROM resumes
            WHERE user_id = %s
            ORDER BY created_at DESC
            LIMIT 1
        """

        cursor.execute(
            query,
            (user_id,)
        )

        resume = cursor.fetchone()

        cursor.close()

        return resume

    # --------------------------------------
    # Update Resume
    # --------------------------------------

    @staticmethod
    def update_resume(
        mysql,
        resume_id,
        full_name,
        email,
        phone,
        address,
        summary,
        education,
        skills,
        experience,
        projects,
        certifications
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE resumes
            SET
                full_name = %s,
                email = %s,
                phone = %s,
                address = %s,
                summary = %s,
                education = %s,
                skills = %s,
                experience = %s,
                projects = %s,
                certifications = %s
            WHERE id = %s
        """

        cursor.execute(
            query,
            (
                full_name,
                email,
                phone,
                address,
                summary,
                education,
                skills,
                experience,
                projects,
                certifications,
                resume_id
            )
        )

        mysql.connection.commit()

        updated_rows = cursor.rowcount

        cursor.close()

        return updated_rows

    # --------------------------------------
    # Delete Resume
    # --------------------------------------

    @staticmethod
    def delete_resume(
        mysql,
        resume_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            DELETE FROM resumes
            WHERE id = %s
        """

        cursor.execute(
            query,
            (resume_id,)
        )

        mysql.connection.commit()

        deleted_rows = cursor.rowcount

        cursor.close()

        return deleted_rows