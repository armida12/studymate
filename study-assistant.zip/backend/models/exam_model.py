# ==========================================
# StudyMate AI - Exam Model
# ==========================================

class ExamModel:

    # --------------------------------------
    # Create Exam Plan
    # --------------------------------------

    @staticmethod
    def create_exam_plan(
        mysql,
        user_id,
        exam_name,
        subject,
        exam_date,
        syllabus,
        study_hours_per_day
    ):

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO exam_plans
            (
                user_id,
                exam_name,
                subject,
                exam_date,
                syllabus,
                study_hours_per_day
            )
            VALUES
            (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        cursor.execute(
            query,
            (
                user_id,
                exam_name,
                subject,
                exam_date,
                syllabus,
                study_hours_per_day
            )
        )

        mysql.connection.commit()

        plan_id = cursor.lastrowid

        cursor.close()

        return plan_id

    # --------------------------------------
    # Get User Exam Plans
    # --------------------------------------

    @staticmethod
    def get_exam_plans(
        mysql,
        user_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                exam_name,
                subject,
                exam_date,
                syllabus,
                study_hours_per_day,
                status,
                created_at
            FROM exam_plans
            WHERE user_id = %s
            ORDER BY exam_date ASC
        """

        cursor.execute(
            query,
            (user_id,)
        )

        plans = cursor.fetchall()

        cursor.close()

        return plans

    # --------------------------------------
    # Get Single Exam Plan
    # --------------------------------------

    @staticmethod
    def get_exam_plan_by_id(
        mysql,
        plan_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            SELECT
                id,
                exam_name,
                subject,
                exam_date,
                syllabus,
                study_hours_per_day,
                status
            FROM exam_plans
            WHERE id = %s
        """

        cursor.execute(
            query,
            (plan_id,)
        )

        plan = cursor.fetchone()

        cursor.close()

        return plan

    # --------------------------------------
    # Update Status
    # --------------------------------------

    @staticmethod
    def update_status(
        mysql,
        plan_id,
        status
    ):

        cursor = mysql.connection.cursor()

        query = """
            UPDATE exam_plans
            SET status = %s
            WHERE id = %s
        """

        cursor.execute(
            query,
            (
                status,
                plan_id
            )
        )

        mysql.connection.commit()

        updated_rows = cursor.rowcount

        cursor.close()

        return updated_rows

    # --------------------------------------
    # Delete Exam Plan
    # --------------------------------------

    @staticmethod
    def delete_exam_plan(
        mysql,
        plan_id
    ):

        cursor = mysql.connection.cursor()

        query = """
            DELETE FROM exam_plans
            WHERE id = %s
        """

        cursor.execute(
            query,
            (plan_id,)
        )

        mysql.connection.commit()

        deleted_rows = cursor.rowcount

        cursor.close()

        return deleted_rows