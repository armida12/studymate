# models/user_model.py

from flask import current_app


class UserModel:

    @staticmethod
    def create_user(mysql, name, email, password):
        """
        Insert a new user into database
        """

        cursor = mysql.connection.cursor()

        query = """
            INSERT INTO users
            (name, email, password)
            VALUES (%s, %s, %s)
        """

        cursor.execute(
            query,
            (name, email, password)
        )

        mysql.connection.commit()

        user_id = cursor.lastrowid

        cursor.close()

        return user_id

    @staticmethod
    def get_user_by_email(mysql, email):
        """
        Find user using email address
        """

        cursor = mysql.connection.cursor()

        query = """
            SELECT id,
                   name,
                   email,
                   password,
                   created_at
            FROM users
            WHERE email = %s
        """

        cursor.execute(query, (email,))

        user = cursor.fetchone()

        cursor.close()

        return user

    @staticmethod
    def get_user_by_id(mysql, user_id):
        """
        Find user using user id
        """

        cursor = mysql.connection.cursor()

        query = """
            SELECT id,
                   name,
                   email,
                   created_at
            FROM users
            WHERE id = %s
        """

        cursor.execute(query, (user_id,))

        user = cursor.fetchone()

        cursor.close()

        return user

    @staticmethod
    def email_exists(mysql, email):
        """
        Check whether email already exists
        """

        cursor = mysql.connection.cursor()

        query = """
            SELECT id
            FROM users
            WHERE email = %s
        """

        cursor.execute(query, (email,))

        exists = cursor.fetchone() is not None

        cursor.close()

        return exists